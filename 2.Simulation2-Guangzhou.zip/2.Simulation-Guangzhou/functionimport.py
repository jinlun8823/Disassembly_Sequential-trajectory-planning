from class_aircraft import Aircraft,speed_adjust_intersection,speed_adjust_sameway,distance,generate_craft_in_s22,get_altD9c
from class_aircraft import generateplaninZGGG,generate_flight_level,generate_craft,generate_craft_in_s2,get_conflict_dic,mid_process

####################飞机生成###################
pl=[[112.8333,24.28],[113.4158,24.19],[113.3833,23.53],[113.5014,23.4],[113.851,23.09],[113.95,22.88],[114.1333,22.53]]
t1='2023-07-23 09:00:00'
cs='CSN631'
aircraft1=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs)
pl2=pl[::-1]
t2='2023-07-23 09:00:00'
cs2='CSN632'
aircraft2=generate_craft_in_s2(planlis=pl2,time=t2,callsign=cs2)

#############################################################
Alis=[aircraft1,aircraft2]

##################冲突探测####################################
craftlis=[aircraft1,aircraft2]    
conflictlisDic=get_conflict_dic(craftlis)
###################################################################

#############################
for craft in craftlis:
    mid_process(craft)
###################################################
altitudeadj=get_altD9c(craftlis=craftlis,conflictlisDic=conflictlisDic)

##################

# def get_instruction(current_point,next_point):
#     instruction={'speed':1000,'flightlevel':9850,'heading':333,'timeinterval':4}###########默认值
#     heading=get_heading(current_point,next_point)
#     instruction['heading']=heading
    
#     #flightlevel=get_flight_level()
#     #instruction['flightlevel']=flightlevel
    
#     #speed=get_speed()
#     #instruction['speed']=speed
    
#     # print(instruction)
#     return instruction
# craftinstruction={}####{Aircraft:{'speed':,'Alt': 'heading='}}####调用
# for craft in altitudeadj.keys():
#     if altitudeadj[craft][0]=='nonlevelcanused':
#         continue
#     else:
#         craftinstruction[craft]=
    
    
    
    

###################针对altitudeadj里面对应为nonlevelcanused的飞机，需要调节速度
# speedadjDicsameway=speed_adjust_sameway(aircraft4,conflictlisDic[aircraft4]['same_way'])


# deltav=speed_adjust_intersection(aircraft1,aircraft2)Alis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7,aircraft8,aircraft9,aircraft10]
for craft in Alis:
    craft.get_change_instruction(instruction=0)
# for t in range(1,10):   
for t in range(len(stamplis)):
    print(t)
    cloudlis=[[114,23.1,0.3],[111.5,23.5,0.4],[113.5,23.5,0.2]]
    ##################每个时间戳加入航空器##########
    conflictlisDic=get_conflict_dic(Alis)
    # print(conflictlisDic)
    # ccc.append(conflictlisDic)
    for craft in Alis:
        mid_process(craft)
    altitudeadj=get_altD9c(craftlis=Alis,conflictlisDic=conflictlisDic)
    # ddd.append(altitudeadj)
    # print(altitudeadj)
    Alis=[aircraft1,aircraft2]
    ###################计算未来几个关键航迹点(比如：4个)################
    for craft in Alis:
        critical_tralis=craft.flightplan
        i_t= get_c_lis(cloudlis,critical_tralis)  
        if i_t == 'diversion':
            Alis.remove(craft)
            # finalAlis.append(craft)
            continue
        else:
            craft.add_critical_track_points(i_t)
        next_point = get_next_track_point(current_point=craft.current_position,tracklis=craft.critical_track_points,v=craft.current_v,height=craft.height)
        if next_point == 'arrive':
            Alis.remove(craft)
            finalAlis.append(craft)
            continue
        elif next_point=='abnormal':
            next_point=[craft.critical_track_points[-1][0],craft.critical_track_points[-1][1]]
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point,altdict=altitudeadj,aircraft=craft,intinstruction=craft.instruction)
        else:
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point['point0'],altdict=altitudeadj,aircraft=craft,intinstruction=craft.instruction)
            # print(instruction)
        # if t == 350:
        #     instruction={'speed':1050,'flightlevel':10400,'heading':60,'timeinterval':4}
        # if instruction['flightlevel'] != 9800:
        #     print('vnaeuirvhnsdfkjvnreiuvhreknsfdvnaeuirvhnsdfkjvnreiuvhreknsfdvnaeuirvhnsdfkjvnreiuvhreknsfd')'
        # craft.get_change_instruction(instruction)
        craft.get_change_instruction(instruction)
        print(craft.instruction)
        craft.doing_current_instruction(craft.instruction,stamplis[t])











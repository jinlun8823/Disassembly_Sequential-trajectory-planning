from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=10.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure(figsize=(20,10))
# fig = plt.figure(figsize=(16, 6))
ax = fig.gca(projection='3d')
# ax.axes.set_box_aspect((1,1,0.5)) # 设定坐标轴的长宽高比例
# plt.gca().set_box_aspect((2, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
# ax.set_aspect('equal','box')
ax.set_box_aspect([1.18,0.5,1.05])
# ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 10.5,
        }#############x,y,z标签的字体
# z_major_locator=MultipleLocator(0.3)
#把x轴的刻度间隔设置为1，并存在变量里

# ax.zaxis.set_major_locator(z_major_locator)
ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
ax.xaxis.set_major_formatter(FormatStrFormatter('%.00f'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.00f'))
ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['color'] = None##############x,y,z网格线颜色
# ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
ax.xaxis._axinfo["grid"]['color'] = None
# ax.xaxis._axinfo["grid"]['linestyle'] = "-"
ax.yaxis._axinfo["grid"]['color'] = None
# ax.yaxis._axinfo["grid"]['linestyle'] = "-"
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.pyplot as plt
ax.set_xlim(109,118)
ax.set_ylim(21.5,25.5)
ax.set_zlim(8.9,10.7)
plt.title("Time = 2023-07-26 12:00:00",loc="center")
# ax.title('time = 2023-07-26')
# plt.axes.get_yaxis().set_visible(False)
# plt.axes.get_xaxis().set_visible(False)
# plt.axis('off')
def plotenv():
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 8.9,'8.9')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.2,'9.2',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.5,'9.5',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.8,'9.8',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.1,'10.1',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.4,'10.4',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.7,'10.7',color='blue')
    
    ###AR02
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x =[114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    ############################################################################################AR03
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    #####################################################################ar04
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    #############################################################################################ar06
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    #########################################################################################AR05
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    ax.view_init(28,270)
# plotenv()
# from matplotlib.path import Path
# import numpy as np
# # import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d.art3d import Poly3DCollection
# fig = plt.figure()
# ax = fig.gca(projection='3d')
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts

def iconPlan(iconMat,height,dx,dy,rotangle):

    iconMat=rot(iconMat, rotangle)
    x=[]
    y=[]
    z=[]

    for i in range(iconMat.shape[0]):
        x.append(iconMat[i,0]+dx)
        y.append(iconMat[i,1]+dy)
        z.append(height)
    newicon=[list(zip(x,y,z))]
    return newicon
# x=[0,1,1,7,7,1,1,3,3,0.3,0,-0.3,-3,-3,-1,-1,-7,-7,-1,-1,0]
# y=[9,8,2,-3,-6,-3,-9,-9.5,-10.5,-10,-12,-10,-10.8,-9.5,-9,-3,-6,-3,2,8,9]
# z = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
# ax.set_xlim(-20,20)
# ax.set_ylim(-20,20)
# ax.set_zlim(-5,5)
iconMat = 0.01*np.array([[0, 9],[1,8],
 			[1, 2],
 			[7, -3],
 			[7, -6],
 			[1, -3],
            [1,-9],
            [3,-9.5],
            [3,-10.8],
            [0.3,-10],
            [0,-12],
            [-0.3,-10],[-3,-10.5],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])
aircrafticon = iconPlan(iconMat=iconMat,height=9.8,dx=115,dy=25,rotangle=180)
aircrafticon =Poly3DCollection(aircrafticon,facecolors='m',alpha=0.8)
ax.add_collection3d(aircrafticon)
t='B737'
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为10，并存在变量里
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
# ax.text(115,25,9.8,t,bbox=dict(boxstyle='round,pad=0.5', fc=None, ec='k',lw=1 ,alpha=0.1))
# ax.scatter(14,5,5)
ax.plot([14,15],[5,9],[5,7],linewidth=1,color='black',alpha=0.3)
# plt.gca().set_box_aspect((1, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
ax.set_xlabel(''+'$\mathrm{'+'Longitude\ (^o)'+'}$',fontdict=font,size=10.5,labelpad=2)########labelpad调轴字间距
ax.set_ylabel(''+'$\mathrm{'+'Latitude\ (^o)'+'}$',fontdict=font,size=10.5,labelpad=2)
ax.set_zlabel(''+'$\mathrm{'+'Altitude\ (km)'+'}$',fontdict=font,size=10.5,labelpad=2)########labelpad调轴字间距
import pandas as pd
import numpy as np
def plotairroutes(ax):
    airroute1=np.array(pd.read_csv('airway1.csv')).T
    airroute2=np.array(pd.read_csv('airway2.csv')).T
    airroute3=np.array(pd.read_csv('airway3.csv')).T
    airroute4=np.array(pd.read_csv('airway4.csv')).T
    airroute5=np.array(pd.read_csv('airway5.csv')).T
    airroute6=np.array(pd.read_csv('airway6.csv')).T
    x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,12):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute1[i,0]))):
            if 109<=eval(airroute1[i,0])[j][0]<=118 and 21<=eval(airroute1[i,0])[j][1]<=25.5:
                x.append(eval(airroute1[i,0])[j][0])
                y.append(eval(airroute1[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
                
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,11):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute2[i,0]))):
            if 109<=eval(airroute2[i,0])[j][0]<=118 and 21<=eval(airroute2[i,0])[j][1]<=25.5:
                x.append(eval(airroute2[i,0])[j][0])
                y.append(eval(airroute2[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
                
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,11):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute3[i,0]))):
            if 109<=eval(airroute3[i,0])[j][0]<=118 and 21<=eval(airroute3[i,0])[j][1]<=25.5:
                x.append(eval(airroute3[i,0])[j][0])
                y.append(eval(airroute3[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.9,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.9,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.9,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,13):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute4[i,0]))):
            if 109<=eval(airroute4[i,0])[j][0]<=118 and 21<=eval(airroute4[i,0])[j][1]<=25.5:
                x.append(eval(airroute4[i,0])[j][0])
                y.append(eval(airroute4[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,56):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute5[i,0]))):
            if 109<=eval(airroute5[i,0])[j][0]<=118 and 21<=eval(airroute5[i,0])[j][1]<=25.5:
                x.append(eval(airroute5[i,0])[j][0])
                y.append(eval(airroute5[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,13):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute6[i,0]))):
            if 109<=eval(airroute6[i,0])[j][0]<=118 and 21<=eval(airroute6[i,0])[j][1]<=25.5:
                x.append(eval(airroute6[i,0])[j][0])
                y.append(eval(airroute6[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
# plt.plot([14,15],[5,9],[5,7],linewidth=1,color='black',alpha=0.3)
plotairroutes(ax)
def elicipse(x,y,z,rx,ry,rz):
    u=np.linspace(0,2*np.pi,20)
    v=np.linspace(0,2*np.pi,20)
    x=rx*np.outer(np.cos(u),np.sin(v))+x
    y=ry*np.outer(np.sin(u),np.sin(v))+y
    z=rz*np.outer(np.ones(np.size(u)),np.cos(v))+z
    ax.plot_surface(x, y, z, cmap='spring',alpha=0.3)
def cylinder(x,y,r,h_min,h):
    # elicipse(x,y,z=h+h_min,rx=r,ry=r,rz=0.000001)
    # elicipse(x,y,z=h_min,rx=r,ry=r,rz=0.000001)
    u = np.linspace(0,2*np.pi,50)  # 把圆分按角度为50等分
    h = np.linspace(0,h,20)         # 把高度1均分为20份####圆柱高
    # th_center
    x =(r)*np.outer(np.sin(u),np.ones(len(h)))+x  # x值重复20次
    y =(r)*np.outer(np.cos(u),np.ones(len(h)))+y # y值重复20次
    z = np.outer(np.ones(len(u)),h)+h_min   # x，y 对应的高度,#底座高
    ax.plot_surface(x, y, z, cmap='winter',alpha=0.2)
# plt.savefig('test', dpi=800, facecolor='w', edgecolor='w' papertype=None, transparent=False, bbox_inches=None, pad_inches=0.1, frameon=None, metadata=None)
cylinder(115,23.5,0.2,8.9,1.8)

plt.savefig('test.png', dpi=700, facecolor=None, edgecolor=None,
          orientation='portrait', papertype=None, format=None,
          transparent=False, bbox_inches=None, pad_inches=0.1,
          frameon=None, metadata=None)

planlis1=[[110.3511,23.5],[110.7209,23.44],[111.0774,23.38],[111.4271,23.29],[111.8175,23.2],[112.4852,23.07],[113.1916,23.02],
          [113.851,23.09],[114.1342,23.12],[114.4503,23.15],[115.7503,23.32]]
planlis1back=planlis1[::-1]
planlis2=[[111.2669,24.2],[111.0774,23.38],[111.6206,22.72],[111.685,22.36],[111.8175,21.57]]
planlis2back=planlis2[::-1]
planlis3=[[111.3008,22.0],[111.685,22.36],[112.4852,23.07],[113.1916,23.02],[113.851,23.07],[114.1342,23.12],
          [114.4503,23.15],[115.7503,23.32]]
planlis3back=planlis3[::-1]
planlis4=[[115.4008,24.67],[114.85,24.28],[114.328,23.65],[114.0169,23.28],[113.851,23.09],[113.1916,23.02],[112.8844,22.48]]
planlis4back=planlis4[::-1]
planlis5=[[116.0905,24.17],[114.328,23.65],[114.0169,23.28],[113.851,23.09],[113.1916,23.02],[112.8844,22.48]]
planlis5back=planlis5[::-1]
planlis6=[[112.8333,24.28],[113.4158,24.19],[113.3833,23.53],[113.5014,23.4],[113.851,23.09],[113.95,22.88],[114.1333,22.53]]
planlis6back=planlis6[::-1]
planlis7=[[113.4158,24.19],[113.851,23.09],[113.95,22.88],[114.1333,22.53]]
planlis7back=planlis7[::-1]
planlis8=[[114.2721,25.1],[114.113,24.35],[113.5876,23.59],[113.1916,23.02],[112.4852,23.07],[111.685,22.36],[111.3008,22]]
planlis8back=planlis8[::-1]
planlis9=[[115.7503,23.32],[114.1342,23.12],[113.851,23.09],[113.1916,23.02],[112.4852,23.07],[111.2669,24.2]]
planlis9back=planlis9[::-1]
planlis10=[[115.4008,24.67],[114.85,24.28],[114.328,23.65],[114.0169,23.28],[113.851,23.09],[113.1916,23.02],[112.4852,23.07],
           [111.685,22.36],[111.3008,22]]
planlis10back=planlis10[::-1]
planlis11=[[114.6342,24.87],[114.5006,24.3],[113.8506,23.5],[113.1916,23.02],[112.8844,22.48]]
planlis11back=planlis11[::-1]
planlis12=[[114.9667,24.75],[114.85,24.28],[114.5573,23.05],[114.5181,22.75]]
planlis12back=planlis12[::-1]
planlis13=[[114.2721,25.1],[114.113,24.35],[114.0014,24.02],[113.8506,23.5],[113.1916,23.02],[111.3008,22]]
planlis13back=planlis13[::-1]
planlis14=[[113.4158,24.19],[113.1916,23.02],[113.4654,22.22]]
planlis14back=planlis14[::-1]
planlis15=[[114.9667,24.75],[114.85,24.28],[114.6175,23.35],[114.5573,23.05],[114.5181,22.75]]
planlis15back=planlis15[::-1]
planlis16=[[116.069,24.33],[114.85,24.28],[114.5006,24.3],[114.113,24.35],[113.4158,24.19],[112.8333,24.28]]
planlis16back=planlis16[::-1]
planlis17=[[112.6014,23.92],[112.7844,23.85],[113.2429,23.67],[113.3833,23.53],[113.5014,23.4],[113.851,23.09],
           [113.95,22.88],[114.1333,22.53]]
planlis17back=planlis17[::-1]
import matplotlib.pyplot as plt
def plotlis(planlis):
    x=[];y=[]
    for i in planlis:
        x.append(i[0])
        y.append(i[1])
    plt.plot(x,y)
# plotlis(planlis17)

import numpy as np
def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d


# Flightplan格式："CA102": [[113.60111111111111, 27.318055555555556, "NIVEM", "2019-05-13 08:05:31"], [113.63472222222222, 28.034722222222225, "MOMRA", "2019-05-13 08:11:11"], [113.68361111111112, 28.551111111111112, "TASAD", "2019-05-13 08:14:51"], [113.71805555555555, 29.101111111111113, "HA310", "2019-05-13 08:19:11"], [114.20452777777778, 30.783055555555556, "WHA", "2019-05-13 08:32:11"], [114.35141666666667, 30.923583333333333, "HG", "2019-05-13 08:33:11"], [114.58388888888888, 32.13444444444444, "P538", "2019-05-13 08:42:51"], [114.63361111111112, 32.36805555555556, "ENLAB", "2019-05-13 08:44:21"], [114.65111111111112, 32.65083333333333, "P123", "2019-05-13 08:47:21"], [114.70138888888889, 33.20055555555556, "DUDBI", "2019-05-13 08:56:31"], [114.75027777777778, 33.58416666666667, "GUTOV", "2019-05-13 08:56:41"], [114.80083333333333, 34.16722222222222, "KILUD", "2019-05-13 08:58:31"], [115.01777777777778, 36.35055555555556, "DADGA", "2019-05-13 09:15:41"], [115.05138888888888, 36.41722222222222, "EKORO", "2019-05-13 09:16:21"], [115.81694444444445, 37.68472222222222, "URDUR", "2019-05-13 09:27:21"]]

import datetime
# planlis=planlis17
# initialtime='2023-07-23 09:00:00'
# planname='lll'

def generateplaninZGGG(planlis,initialtime,planname):
    flightplan={planname:[]}
    nowtime=datetime.datetime.strptime(initialtime,"%Y-%m-%d %H:%M:%S")
    
    for i in range(len(planlis)-1):
        flightplan[planname].append([planlis[i][0],planlis[i][1],'point'+str(i),nowtime])
        runningtime = (distance(planlis[i],planlis[i+1])/850)*3600
        nowtime += datetime.timedelta(seconds = round(runningtime,0))
    flightplan[planname].append([planlis[i+1][0],planlis[i+1][1],'point'+str(i+1),nowtime])    
    return flightplan
flightplan1=generateplaninZGGG(planlis1,'2023-07-23 09:00:00','CA2107')

from class_aircraft import Aircraft
import random
def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita
def generate_flight_level(current_point,next_point):
    heading=get_heading(current_point,next_point)
    if 0 < heading <= 180:
        levellis = [10700,10100,9500,8900]
        height=random.choice(levellis)
    else:
        levellis = [10400,9800,9200]
        height=random.choice(levellis)
    return height
#########第一波飞机，每个航路来1架，随机高度层，泊松分布

def generate_craft(flightplan):
    callsign1=list(flightplan.keys())[0]
    aircraft = Aircraft(callsign=callsign1,flightplan=flightplan[callsign1],critical_track_points=flightplan[callsign1],
                          current_position=[flightplan[callsign1][0][0],flightplan[callsign1][0][1]],
                          height=generate_flight_level(flightplan[callsign1][0],flightplan[callsign1][1]),
                          heading=get_heading(flightplan[callsign1][0],flightplan[callsign1][1]))
    return aircraft
######第一波飞机
flightplan1=generateplaninZGGG(planlis1,'2023-07-23 09:00:00','CA2107')
aircraft1 = generate_craft(flightplan1)
flightplan2=generateplaninZGGG(planlis2,'2023-07-23 09:00:00','MU5128')
aircraft2 = generate_craft(flightplan2)
flightplan3=generateplaninZGGG(planlis3,'2023-07-23 09:00:00','MU5129')
aircraft3 = generate_craft(flightplan3)
flightplan4=generateplaninZGGG(planlis4,'2023-07-23 09:00:00','MU5130')
aircraft4 = generate_craft(flightplan4)
flightplan5=generateplaninZGGG(planlis5,'2023-07-23 09:00:00','MU5131')
aircraft5 = generate_craft(flightplan5)
flightplan6=generateplaninZGGG(planlis6,'2023-07-23 09:00:00','MU5132')
aircraft6 = generate_craft(flightplan6)
flightplan7=generateplaninZGGG(planlis7,'2023-07-23 09:00:00','MU5133')
aircraft7 = generate_craft(flightplan7)
flightplan8=generateplaninZGGG(planlis8,'2023-07-23 09:00:00','MU5134')
aircraft8 = generate_craft(flightplan8)
flightplan9=generateplaninZGGG(planlis9,'2023-07-23 09:00:00','MU5135')
aircraft9 = generate_craft(flightplan9)
flightplan10=generateplaninZGGG(planlis10,'2023-07-23 09:00:00','MU5136')
aircraft10 = generate_craft(flightplan10)
flightplan11=generateplaninZGGG(planlis11,'2023-07-23 09:00:00','MU5137')
aircraft11 = generate_craft(flightplan11)
flightplan12=generateplaninZGGG(planlis12,'2023-07-23 09:00:00','MU5138')
aircraft12 = generate_craft(flightplan12)
flightplan13=generateplaninZGGG(planlis13,'2023-07-23 09:00:00','MU5139')
aircraft13 = generate_craft(flightplan13)
flightplan14=generateplaninZGGG(planlis14,'2023-07-23 09:00:00','MU5140')
aircraft14 = generate_craft(flightplan14)
flightplan15=generateplaninZGGG(planlis1back,'2023-07-23 09:00:00','MU5140')
aircraft15 = generate_craft(flightplan15)
flightplan16=generateplaninZGGG(planlis2back,'2023-07-23 09:00:00','MU5142')
aircraft16 = generate_craft(flightplan16)
flightplan17=generateplaninZGGG(planlis3back,'2023-07-23 09:00:00','MU5143')
aircraft17 = generate_craft(flightplan17)
flightplan18=generateplaninZGGG(planlis4back,'2023-07-23 09:00:00','MU5144')
aircraft18 = generate_craft(flightplan18)
flightplan19=generateplaninZGGG(planlis5back,'2023-07-23 09:00:00','MU5145')
aircraft19 = generate_craft(flightplan19)
flightplan20=generateplaninZGGG(planlis6back,'2023-07-23 09:00:00','MU5146')
aircraft20 = generate_craft(flightplan20)
flightplan21=generateplaninZGGG(planlis7back,'2023-07-23 09:00:00','MU5147')
aircraft21 = generate_craft(flightplan21)
flightplan22=generateplaninZGGG(planlis8back,'2023-07-23 09:00:00','MU5148')
aircraft22 = generate_craft(flightplan22)
flightplan23=generateplaninZGGG(planlis9back,'2023-07-23 09:00:00','MU5149')
aircraft23 = generate_craft(flightplan23)
flightplan24=generateplaninZGGG(planlis10back,'2023-07-23 09:00:00','MU5150')
aircraft24 = generate_craft(flightplan24)
flightplan25=generateplaninZGGG(planlis11back,'2023-07-23 09:00:00','MU5151')
aircraft25 = generate_craft(flightplan25)
flightplan26=generateplaninZGGG(planlis12back,'2023-07-23 09:00:00','MU5152')
aircraft26 = generate_craft(flightplan26)
flightplan27=generateplaninZGGG(planlis13back,'2023-07-23 09:00:00','MU5153')
aircraft27 = generate_craft(flightplan27)
flightplan28=generateplaninZGGG(planlis14back,'2023-07-23 09:00:00','MU5154')
aircraft28 = generate_craft(flightplan28)

########间隔2min后，每个航路来一架，随机高度层，任意删除10架次


# flightplan29=generateplaninZGGG(planlis8,'2023-07-23 09:03:00','MU5134')
# aircraft29 = generate_craft(flightplan29)
# flightplan30=generateplaninZGGG(planlis9,'2023-07-23 09:03:00','MU5135')
# aircraft30 = generate_craft(flightplan30)
# flightplan31=generateplaninZGGG(planlis10,'2023-07-23 09:03:00','MU5136')
# aircraft31 = generate_craft(flightplan31)
# flightplan32=generateplaninZGGG(planlis6back,'2023-07-23 09:03:00','MU5146')
# aircraft32 = generate_craft(flightplan32)
# flightplan33=generateplaninZGGG(planlis7back,'2023-07-23 09:03:00','MU5147')
# aircraft33 = generate_craft(flightplan33)
# flightplan34=generateplaninZGGG(planlis8back,'2023-07-23 09:03:00','MU5148')
# aircraft34 = generate_craft(flightplan34)
# flightplan35=generateplaninZGGG(planlis9back,'2023-07-23 09:03:00','MU5149')
# aircraft35 = generate_craft(flightplan35)
# flightplan36=generateplaninZGGG(planlis10back,'2023-07-23 09:03:00','MU5150')
# aircraft36 = generate_craft(flightplan36)
# flightplan37=generateplaninZGGG(planlis11back,'2023-07-23 09:03:00','MU5151')
# aircraft37 = generate_craft(flightplan37)
# flightplan38=generateplaninZGGG(planlis12back,'2023-07-23 09:03:00','MU5152')
# aircraft38 = generate_craft(flightplan38)
# flightplan39=generateplaninZGGG(planlis13back,'2023-07-23 09:03:00','MU5153')
# aircraft39 = generate_craft(flightplan39)


#######间隔3min后，每个航路来一架，任意删除10架次




#####间隔4min后，每个航路来一架，任意删除10架次



#####间隔3min后，每个航路来一架，任意删除10架次



#####间隔2min后，每个航路来一架，任意删除10架次


#######测试按照计划飞行的航迹
# from generate_track_basedon_critical_points import get_next_track_point,get_instruction
# for i in range(3600):
#     next_point = get_next_track_point(current_point=aircraft7.current_position,tracklis=aircraft7.critical_track_points,v=aircraft7.current_v,height=aircraft7.height)
#     # print(next_point )
#     if next_point == 'arrive':
#         break
#     elif next_point=='abnormal':
#         next_point=aircraft7.critical_track_points[-1]
#         instruction = get_instruction(current_point=aircraft7.current_position,next_point=next_point)
#     else:
#         instruction = get_instruction(current_point=aircraft7.current_position,next_point=next_point['point0'])
#     # print(instruction)
#     aircraft7.doing_current_instruction(instruction,0)
#     i=i+1
#     print(i)

##############三维图像###############
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

# plt.rcParams["font.family"]='Times New Roman'######全局字体
# plt.rcParams["font.size"]=10.5##########五号
# plt.rcParams["text.color"]='black'
# plt.rcParams["mathtext.fontset"]='stix'
# fig = plt.figure(figsize=(20,10))
# # fig = plt.figure(figsize=(16, 6))
# ax = fig.gca(projection='3d')
# # ax.axes.set_box_aspect((1,1,0.5)) # 设定坐标轴的长宽高比例
# # plt.gca().set_box_aspect((2, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
# # ax.set_aspect('equal','box')
# ax.set_box_aspect([1.18,0.5,1.05])
# # ax = fig.gca()
# font = {'family': 'SimSun',
#         'color':  'black',
#         'weight': 'normal',
#         'size': 10.5,
#         }#############x,y,z标签的字体
# # z_major_locator=MultipleLocator(0.3)
# #把x轴的刻度间隔设置为1，并存在变量里
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为10，并存在变量里
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# # ax.zaxis.set_major_locator(z_major_locator)
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
# ax.xaxis.set_major_formatter(FormatStrFormatter('%.00f'))
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.00f'))
# ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
# ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['color'] = None##############x,y,z网格线颜色
# # ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
# ax.xaxis._axinfo["grid"]['color'] = None
# # ax.xaxis._axinfo["grid"]['linestyle'] = "-"
# ax.yaxis._axinfo["grid"]['color'] = None
# # ax.yaxis._axinfo["grid"]['linestyle'] = "-"

# ax.set_xlim(109,118)
# ax.set_ylim(21.5,25.5)
# ax.set_zlim(8.9,10.7)
# plt.title("Time = 2023-07-26 12:00:00",loc="center")
# ax.title('time = 2023-07-26')
# plt.axes.get_yaxis().set_visible(False)
# plt.axes.get_xaxis().set_visible(False)
# plt.axis('off')
def plotenv(ax):
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 8.9,'8.9')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.2,'9.2',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.5,'9.5',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.8,'9.8',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.1,'10.1',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.4,'10.4',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.7,'10.7',color='blue')
    ###AR02
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x =[114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    ############################################################################################AR03
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    #####################################################################ar04
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    #############################################################################################ar06
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    #########################################################################################AR05
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    ax.view_init(28,270)

# xx=[];yy=[];zz=[]
# for i in aircraft7.tracklis:
#     xx.append(i[0])
#     yy.append(i[1])
#     zz.append(i[2]/1000)
# ax.plot(xx,yy,zz)

def getFutureTime(timestamp,it,format='%Y-%m-%d %H:%M:%S'):
    '''
    以给定时间戳为基准，前进 hours 个小时得到对应的时间戳
    '''
    now_time=datetime.datetime.strptime(timestamp,'%Y-%m-%d %H:%M:%S')
    for i in range(it):
        now_time+=datetime.timedelta(seconds=4)
    next_timestamp=now_time.strftime('%Y-%m-%d %H:%M:%S')
    # print ('next_timestamp: ',next_timestamp)
    return next_timestamp
timestamp='2020-07-23 09:00:00'
stamplis=[]
for i in range(900):
    tt=getFutureTime(timestamp, it=i, format='%Y-%m-%d %H:%M:%S')
    stamplis.append(tt)

from generate_track_basedon_critical_points import get_next_track_point,get_instruction,get_next_track4,get_heading
from multi_cb_conflicts_resolve import get_c_lis
finalAlis=[]
for t in range(len(stamplis)):
    # print(t)
    cloudlis=[[114,23.1,0.3],[111.5,23.5,0.4],[113.5,23.5,0.2]]
    ##################每个时间戳加入航空器##########
    Alis=[aircraft6]
    ###################计算未来几个关键航迹点(比如：4个)################
    for craft in Alis:
        critical_tralis=craft.flightplan
        i_t= get_c_lis(cloudlis,critical_tralis)  
        # print(i_t)
        if i_t == 'diversion':
            Alis.remove(craft)
            # finalAlis.append(craft)
            continue
        else:
            craft.add_critical_track_points(i_t)
        next_point = get_next_track_point(current_point=craft.current_position,tracklis=craft.critical_track_points,v=craft.current_v,height=craft.height)
        # print(next_point)
        if next_point == 'arrive':
            print('arrive')
            Alis.remove(craft)
            finalAlis.append(craft)
            continue
        elif next_point=='abnormal':
            print('abnormal')
            next_point=[craft.critical_track_points[-1][0],craft.critical_track_points[-1][1]]
            # print(next_point)
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point)
        else:
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point['point0'])
        craft.doing_current_instruction(instruction,stamplis[t])
def plotcraft(aircraft,time,ax,cc):
    xx=[];yy=[];zz=[]
    for i in range(time):
        xx.append(aircraft.tracklis[i][0])
        yy.append(aircraft.tracklis[i][1])
        zz.append(aircraft.tracklis[i][2]/1000)
    ax.plot(xx,yy, zz, color=cc)
def elicipse(x,y,z,rx,ry,rz,ax):
    u=np.linspace(0,2*np.pi,20)
    v=np.linspace(0,2*np.pi,20)
    x=rx*np.outer(np.cos(u),np.sin(v))+x
    y=ry*np.outer(np.sin(u),np.sin(v))+y
    z=rz*np.outer(np.ones(np.size(u)),np.cos(v))+z
    ax.plot_surface(x, y, z, cmap='spring',alpha=0.3)
def cylinder(x,y,r,h_min,h,ax):
    # elicipse(x,y,z=h+h_min,rx=r,ry=r,rz=0.000001)
    # elicipse(x,y,z=h_min,rx=r,ry=r,rz=0.000001)
    u = np.linspace(0,2*np.pi,50)  # 把圆分按角度为50等分
    h = np.linspace(0,h,20)         # 把高度1均分为20份####圆柱高
    # th_center
    x =(r)*np.outer(np.sin(u),np.ones(len(h)))+x  # x值重复20次
    y =(r)*np.outer(np.cos(u),np.ones(len(h)))+y # y值重复20次
    z = np.outer(np.ones(len(u)),h)+h_min   # x，y 对应的高度,#底座高
    ax.plot_surface(x, y, z, cmap='winter',alpha=0.2)
# plt.savefig('test', dpi=800, facecolor='w', edgecolor='w' papertype=None, transparent=False, bbox_inches=None, pad_inches=0.1, frameon=None, metadata=None)

from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=10.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure(figsize=(20,10))
# fig = plt.figure(figsize=(16, 6))
ax = fig.gca(projection='3d')
# ax.axes.set_box_aspect((1,1,0.5)) # 设定坐标轴的长宽高比例
# plt.gca().set_box_aspect((2, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
# ax.set_aspect('equal','box')
ax.set_box_aspect([1.18,0.5,1.05])
# ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 10.5,
        }#############x,y,z标签的字体
# z_major_locator=MultipleLocator(0.3)
#把x轴的刻度间隔设置为1，并存在变量里
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为10，并存在变量里
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
# ax.zaxis.set_major_locator(z_major_locator)
ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
ax.xaxis.set_major_formatter(FormatStrFormatter('%.00f'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.00f'))
ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['color'] = None##############x,y,z网格线颜色
# ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
ax.xaxis._axinfo["grid"]['color'] = None
# ax.xaxis._axinfo["grid"]['linestyle'] = "-"
ax.yaxis._axinfo["grid"]['color'] = None
# ax.yaxis._axinfo["grid"]['linestyle'] = "-"
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.pyplot as plt
ax.set_xlim(109,118)
ax.set_ylim(21.5,25.5)
ax.set_zlim(8.9,10.7)
plt.title("Time = 2023-07-26 12:00:00",loc="center")
plotenv(ax)
cylinder(114,23.1,0.3,8.9,1.8,ax)    
cylinder(111.5,23.5,0.4,8.9,1.8,ax) 
cylinder(113.5,23.5,0.2,8.9,1.8,ax) 


plotcraft(aircraft6,245,ax,cc='blue')

x=[];y=[];z=[]

for i in i_t:
    x.append(i[0])
    y.append(i[1])
    z.append(9.85)
ax.scatter(x,y,z)    
    
# ###############################制作gif动画测试################
# # plt.savefig(f"{1}.png")

# plt.savefig('6.png', dpi=700, facecolor=None, edgecolor=None,
#           orientation='portrait', papertype=None, format=None,
#           transparent=False, bbox_inches=None, pad_inches=0.1,
#           frameon=None, metadata=None)

# frames=6
# from PIL import Image
# images = [Image.open(f"{n}.png") for n in range(1,frames)]

# images[0].save('simulation2.gif', save_all=True, append_images=images[1:], duration=300, loop=0)
# plt.legend()








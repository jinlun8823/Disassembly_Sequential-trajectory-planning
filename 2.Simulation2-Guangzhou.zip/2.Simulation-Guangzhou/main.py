planlis1=[[110.3511,23.5],[110.7209,23.44],[111.0774,23.38],[111.4271,23.29],[111.8175,23.2],[112.4852,23.07],[113.1916,23.02],
          [113.851,23.09],[114.1342,23.12],[114.4503,23.15],[115.7503,23.32]]
planlis1back=planlis1[::-1]
planlis2=[[111.2669,24.2],[111.0774,23.38],[111.6206,22.72],[111.685,22.36],[111.8175,21.57]]
planlis2back=planlis2[::-1]
planlis3=[[111.3008,22.0],[111.685,22.36],[112.4852,23.07],[113.1916,23.02],[113.851,23.07],[114.1342,23.12],
          [114.4503,23.15],[115.7503,23.32]]
planlis3back=planlis3[::-1]
planlis4=[[115.4008,24.67],[114.85,24.28],[114.328,23.65],[114.0169,23.28],[113.851,23.09],[113.1916,23.02],[112.8844,22.48]]
planlis4back=planlis4[::-1]
planlis5=[[116.0905,24.17],[114.328,23.65],[114.0169,23.28],[113.851,23.09],[113.1916,23.02],[112.8844,22.48]]
planlis5back=planlis5[::-1]
planlis6=[[112.8333,24.28],[113.4158,24.19],[113.3833,23.53],[113.5014,23.4],[113.851,23.09],[113.95,22.88],[114.1333,22.53]]
planlis6back=planlis6[::-1]
planlis7=[[113.4158,24.19],[113.851,23.09],[113.95,22.88],[114.1333,22.53]]
planlis7back=planlis7[::-1]
planlis8=[[114.2721,25.1],[114.113,24.35],[113.5876,23.59],[113.1916,23.02],[112.4852,23.07],[111.685,22.36],[111.3008,22]]
planlis8back=planlis8[::-1]
planlis9=[[115.7503,23.32],[114.1342,23.12],[113.851,23.09],[113.1916,23.02],[112.4852,23.07],[111.2669,24.2]]
planlis9back=planlis9[::-1]
planlis10=[[115.4008,24.67],[114.85,24.28],[114.328,23.65],[114.0169,23.28],[113.851,23.09],[113.1916,23.02],[112.4852,23.07],
           [111.685,22.36],[111.3008,22]]
planlis10back=planlis10[::-1]
planlis11=[[114.6342,24.87],[114.5006,24.3],[113.8506,23.5],[113.1916,23.02],[112.8844,22.48]]
planlis11back=planlis11[::-1]
planlis12=[[114.9667,24.75],[114.85,24.28],[114.5573,23.05],[114.5181,22.75]]
planlis12back=planlis12[::-1]
planlis13=[[114.2721,25.1],[114.113,24.35],[114.0014,24.02],[113.8506,23.5],[113.1916,23.02],[111.3008,22]]
planlis13back=planlis13[::-1]
planlis14=[[113.4158,24.19],[113.1916,23.02],[113.4654,22.22]]
planlis14back=planlis14[::-1]
planlis15=[[114.9667,24.75],[114.85,24.28],[114.6175,23.35],[114.5573,23.05],[114.5181,22.75]]
planlis15back=planlis15[::-1]
planlis16=[[116.069,24.33],[114.85,24.28],[114.5006,24.3],[114.113,24.35],[113.4158,24.19],[112.8333,24.28]]
planlis16back=planlis16[::-1]
planlis17=[[112.6014,23.92],[112.7844,23.85],[113.2429,23.67],[113.3833,23.53],[113.5014,23.4],[113.851,23.09],
           [113.95,22.88],[114.1333,22.53]]
planlis17back=planlis17[::-1]
import matplotlib.pyplot as plt
def plotlis(planlis):
    x=[];y=[]
    for i in planlis:
        x.append(i[0])
        y.append(i[1])
    plt.plot(x,y)
# plotlis(planlis17)

import numpy as np
def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d


# Flightplan格式："CA102": [[113.60111111111111, 27.318055555555556, "NIVEM", "2019-05-13 08:05:31"], [113.63472222222222, 28.034722222222225, "MOMRA", "2019-05-13 08:11:11"], [113.68361111111112, 28.551111111111112, "TASAD", "2019-05-13 08:14:51"], [113.71805555555555, 29.101111111111113, "HA310", "2019-05-13 08:19:11"], [114.20452777777778, 30.783055555555556, "WHA", "2019-05-13 08:32:11"], [114.35141666666667, 30.923583333333333, "HG", "2019-05-13 08:33:11"], [114.58388888888888, 32.13444444444444, "P538", "2019-05-13 08:42:51"], [114.63361111111112, 32.36805555555556, "ENLAB", "2019-05-13 08:44:21"], [114.65111111111112, 32.65083333333333, "P123", "2019-05-13 08:47:21"], [114.70138888888889, 33.20055555555556, "DUDBI", "2019-05-13 08:56:31"], [114.75027777777778, 33.58416666666667, "GUTOV", "2019-05-13 08:56:41"], [114.80083333333333, 34.16722222222222, "KILUD", "2019-05-13 08:58:31"], [115.01777777777778, 36.35055555555556, "DADGA", "2019-05-13 09:15:41"], [115.05138888888888, 36.41722222222222, "EKORO", "2019-05-13 09:16:21"], [115.81694444444445, 37.68472222222222, "URDUR", "2019-05-13 09:27:21"]]

import datetime
# planlis=planlis17
# initialtime='2023-07-23 09:00:00'
# planname='lll'

def generateplaninZGGG(planlis,initialtime,planname):
    flightplan={planname:[]}
    nowtime=datetime.datetime.strptime(initialtime,"%Y-%m-%d %H:%M:%S")
    
    for i in range(len(planlis)-1):
        flightplan[planname].append([planlis[i][0],planlis[i][1],'point'+str(i),nowtime])
        runningtime = (distance(planlis[i],planlis[i+1])/850)*3600
        nowtime += datetime.timedelta(seconds = round(runningtime,0))
    flightplan[planname].append([planlis[i+1][0],planlis[i+1][1],'point'+str(i+1),nowtime])    
    return flightplan
flightplan1=generateplaninZGGG(planlis1,'2023-07-23 09:00:00','CA2107')

from class_aircraft import Aircraft
import random
def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita
def generate_flight_level(current_point,next_point):
    heading=get_heading(current_point,next_point)
    if 0 < heading <= 180:
        levellis = [10700,10100,9500,8900]
        height=random.choice(levellis)
    else:
        levellis = [10400,9800,9200]
        height=random.choice(levellis)
    return height
#########第一波飞机，每个航路来1架，随机高度层，泊松分布
from class_aircraft import Aircraft,speed_adjust_intersection,speed_adjust_sameway,distance,generate_craft_in_s22,get_altD9c
from class_aircraft import generateplaninZGGG,generate_flight_level,generate_craft,generate_craft_in_s2,get_conflict_dic,mid_process
from class_aircraft import agent_control
# def generate_craft(flightplan):
#     callsign1=list(flightplan.keys())[0]
#     aircraft = Aircraft(callsign=callsign1,flightplan=flightplan[callsign1],critical_track_points=flightplan[callsign1],
#                           current_position=[flightplan[callsign1][0][0],flightplan[callsign1][0][1]],
#                           height=generate_flight_level(flightplan[callsign1][0],flightplan[callsign1][1]),
#                           heading=get_heading(flightplan[callsign1][0],flightplan[callsign1][1]))
#     return aircraft
######第一波飞机
pl=planlis1;t1='2023-07-23 09:00:00';cs='CA2107'
aircraft1=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9500)
# flightplan1=generateplaninZGGG(planlis1,'2023-07-23 09:00:00','CA2107')
# aircraft1 = generate_craft(flightplan1)
pl=planlis2;t1='2023-07-23 09:00:00';cs='MU5128'
aircraft2=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)
# flightplan2=generateplaninZGGG(planlis2,'2023-07-23 09:00:00','MU5128')
# aircraft2 = generate_craft(flightplan2)
pl=planlis17;t1='2023-07-23 09:00:00';cs='MU5129'
aircraft3=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10100)
# flightplan3=generateplaninZGGG(planlis3,'2023-07-23 09:00:00','MU5129')
# aircraft3 = generate_craft(flightplan3)
pl=planlis4;t1='2023-07-23 09:00:00';cs='MU5130'
aircraft4=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=8900)
# flightplan4=generateplaninZGGG(planlis4,'2023-07-23 09:00:00','MU5130')
# aircraft4 = generate_craft(flightplan4)
pl=planlis5;t1='2023-07-23 09:00:00';cs='MU5131'
aircraft5=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)
# flightplan5=generateplaninZGGG(planlis5,'2023-07-23 09:00:00','MU5131')
# aircraft5 = generate_craft(flightplan5)
pl=planlis6;t1='2023-07-23 09:00:00';cs='MU5132'
aircraft6=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10100)
# flightplan6=generateplaninZGGG(planlis6,'2023-07-23 09:00:00','MU5132')
# aircraft6 = generate_craft(flightplan6)
pl=planlis7;t1='2023-07-23 09:00:00';cs='MU5133'
aircraft7=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10700)
# flightplan7=generateplaninZGGG(planlis7,'2023-07-23 09:00:00','MU5133')
# aircraft7 = generate_craft(flightplan7)
pl=planlis8;t1='2023-07-23 09:00:00';cs='MU5134'
aircraft8=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)
# flightplan8=generateplaninZGGG(planlis8,'2023-07-23 09:00:00','MU5134')
# aircraft8 = generate_craft(flightplan8)
pl=planlis9;t1='2023-07-23 09:00:00';cs='MU5135'
aircraft9=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)
# flightplan9=generateplaninZGGG(planlis9,'2023-07-23 09:00:00','MU5135')
# aircraft9 = generate_craft(flightplan9)
pl=planlis10;t1='2023-07-23 09:00:00';cs='MU5136'
aircraft10=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan10=generateplaninZGGG(planlis10,'2023-07-23 09:00:00','MU5136')
# aircraft10 = generate_craft(flightplan10)
pl=planlis11;t1='2023-07-23 09:00:00';cs='MU5137'
aircraft11=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)
# flightplan11=generateplaninZGGG(planlis11,'2023-07-23 09:00:00','MU5137')
# aircraft11 = generate_craft(flightplan11)
pl=planlis12;t1='2023-07-23 09:00:00';cs='MU5138'
aircraft12=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)
# flightplan12=generateplaninZGGG(planlis12,'2023-07-23 09:00:00','MU5138')
# aircraft12 = generate_craft(flightplan12)
pl=planlis13;t1='2023-07-23 09:00:00';cs='MU5139'
aircraft13=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan13=generateplaninZGGG(planlis13,'2023-07-23 09:00:00','MU5139')
# aircraft13 = generate_craft(flightplan13)
pl=planlis14;t1='2023-07-23 09:00:00';cs='MU5140'
aircraft14=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)
# flightplan14=generateplaninZGGG(planlis14,'2023-07-23 09:00:00','MU5140')
# aircraft14 = generate_craft(flightplan14)
pl=planlis1back;t1='2023-07-23 09:00:00';cs='MU5141'
aircraft15=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)
# flightplan15=generateplaninZGGG(planlis1back,'2023-07-23 09:00:00','MU5140')
# aircraft15 = generate_craft(flightplan15)
pl=planlis2back;t1='2023-07-23 09:00:00';cs='MU5142'
aircraft16=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan16=generateplaninZGGG(planlis2back,'2023-07-23 09:00:00','MU5142')
# aircraft16 = generate_craft(flightplan16)
pl=planlis3back;t1='2023-07-23 09:00:00';cs='MU5143'
aircraft17=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan17=generateplaninZGGG(planlis3back,'2023-07-23 09:00:00','MU5143')
# aircraft17 = generate_craft(flightplan17)
pl=planlis4back;t1='2023-07-23 09:00:00';cs='MU5144'
aircraft18=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan18=generateplaninZGGG(planlis4back,'2023-07-23 09:00:00','MU5144')
# aircraft18 = generate_craft(flightplan18)
pl=planlis5back;t1='2023-07-23 09:00:00';cs='MU5145'
aircraft19=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan19=generateplaninZGGG(planlis5back,'2023-07-23 09:00:00','MU5145')
# aircraft19 = generate_craft(flightplan19)
pl=planlis6back;t1='2023-07-23 09:00:00';cs='MU5146'
aircraft20=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)
# flightplan20=generateplaninZGGG(planlis6back,'2023-07-23 09:00:00','MU5146')
# aircraft20 = generate_craft(flightplan20)
pl=planlis7back;t1='2023-07-23 09:00:00';cs='MU5147'
aircraft21=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan21=generateplaninZGGG(planlis7back,'2023-07-23 09:00:00','MU5147')
# aircraft21 = generate_craft(flightplan21)
pl=planlis1;t1='2023-07-23 09:00:00';cs='MU5148'
aircraft22=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=8900)
# flightplan22=generateplaninZGGG(planlis8back,'2023-07-23 09:00:00','MU5148')
# aircraft22 = generate_craft(flightplan22)
pl=planlis9back;t1='2023-07-23 09:00:00';cs='MU5149'
aircraft23=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10100)
# flightplan23=generateplaninZGGG(planlis9back,'2023-07-23 09:00:00','MU5149')
# aircraft23 = generate_craft(flightplan23)
pl=planlis10;t1='2023-07-23 09:00:00';cs='MU5150'
aircraft24=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=8900)
# flightplan24=generateplaninZGGG(planlis10back,'2023-07-23 09:00:00','MU5150')
# aircraft24 = generate_craft(flightplan24)
pl=planlis11back;t1='2023-07-23 09:00:00';cs='MU5151'
aircraft25=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9500)
# flightplan25=generateplaninZGGG(planlis11back,'2023-07-23 09:00:00','MU5151')
# aircraft25 = generate_craft(flightplan25)
pl=planlis12back;t1='2023-07-23 09:00:00';cs='MU5152'
aircraft26=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)
# flightplan26=generateplaninZGGG(planlis12back,'2023-07-23 09:00:00','MU5152')
# aircraft26 = generate_craft(flightplan26)
pl=planlis13back;t1='2023-07-23 09:00:00';cs='MU5153'
aircraft27=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10100)
# flightplan27=generateplaninZGGG(planlis13back,'2023-07-23 09:00:00','MU5153')
# aircraft27 = generate_craft(flightplan27)
pl=planlis14back;t1='2023-07-23 09:00:00';cs='MU5154'
aircraft28=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9500)
# flightplan28=generateplaninZGGG(planlis14back,'2023-07-23 09:00:00','MU5154')
# aircraft28 = generate_craft(flightplan28)

########间隔2min后，每个航路来一架，随机高度层，任意删除10架次
pl=planlis1;t1='2023-07-23 09:05:00';cs='CA2107c'
aircraft29=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10700)
# flightplan1=generateplaninZGGG(planlis1,'2023-07-23 09:00:00','CA2107')
# aircraft1 = generate_craft(flightplan1)
pl=planlis2;t1='2023-07-23 09:05:00';cs='MU5128c'
aircraft30=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10100)
# flightplan2=generateplaninZGGG(planlis2,'2023-07-23 09:00:00','MU5128')
# aircraft2 = generate_craft(flightplan2)
pl=planlis3;t1='2023-07-23 09:05:00';cs='MU5129c'
aircraft31=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9500)
# flightplan3=generateplaninZGGG(planlis3,'2023-07-23 09:00:00','MU5129')
# aircraft3 = generate_craft(flightplan3)
pl=planlis4;t1='2023-07-23 09:05:00';cs='MU5130c'
aircraft4c=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)
# flightplan4=generateplaninZGGG(planlis4,'2023-07-23 09:00:00','MU5130')
# aircraft4 = generate_craft(flightplan4)
pl=planlis5;t1='2023-07-23 09:05:00';cs='MU5131c'
aircraft5c=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=10400)


pl=planlis1back;t1='2023-07-23 09:05:00';cs='MU5136c'
aircraft6c=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)

pl=planlis13;t1='2023-07-23 09:05:00';cs='MU5137c'
aircraft7c=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9200)
# flightplan29=generateplaninZGGG(planlis8,'2023-07-23 09:03:00','MU5134')
# aircraft29 = generate_craft(flightplan29)
# flightplan30=generateplaninZGGG(planlis9,'2023-07-23 09:03:00','MU5135')
# aircraft30 = generate_craft(flightplan30)
# flightplan31=generateplaninZGGG(planlis10,'2023-07-23 09:03:00','MU5136')
# aircraft31 = generate_craft(flightplan31)
# flightplan32=generateplaninZGGG(planlis6back,'2023-07-23 09:03:00','MU5146')
# aircraft32 = generate_craft(flightplan32)
# flightplan33=generateplaninZGGG(planlis7back,'2023-07-23 09:03:00','MU5147')
# aircraft33 = generate_craft(flightplan33)
# flightplan34=generateplaninZGGG(planlis8back,'2023-07-23 09:03:00','MU5148')
# aircraft34 = generate_craft(flightplan34)
# flightplan35=generateplaninZGGG(planlis9back,'2023-07-23 09:03:00','MU5149')
# aircraft35 = generate_craft(flightplan35)
# flightplan36=generateplaninZGGG(planlis10back,'2023-07-23 09:03:00','MU5150')
# aircraft36 = generate_craft(flightplan36)
# flightplan37=generateplaninZGGG(planlis11back,'2023-07-23 09:03:00','MU5151')
# aircraft37 = generate_craft(flightplan37)
# flightplan38=generateplaninZGGG(planlis12back,'2023-07-23 09:03:00','MU5152')
# aircraft38 = generate_craft(flightplan38)
# flightplan39=generateplaninZGGG(planlis13back,'2023-07-23 09:03:00','MU5153')
# aircraft39 = generate_craft(flightplan39)


#######间隔3min后，每个航路来一架，任意删除10架次




#####间隔4min后，每个航路来一架，任意删除10架次



#####间隔3min后，每个航路来一架，任意删除10架次



#####间隔2min后，每个航路来一架，任意删除10架次


#######测试按照计划飞行的航迹
# from generate_track_basedon_critical_points import get_next_track_point,get_instruction
# for i in range(3600):
#     next_point = get_next_track_point(current_point=aircraft7.current_position,tracklis=aircraft7.critical_track_points,v=aircraft7.current_v,height=aircraft7.height)
#     # print(next_point )
#     if next_point == 'arrive':
#         break
#     elif next_point=='abnormal':
#         next_point=aircraft7.critical_track_points[-1]
#         instruction = get_instruction(current_point=aircraft7.current_position,next_point=next_point)
#     else:
#         instruction = get_instruction(current_point=aircraft7.current_position,next_point=next_point['point0'])
#     # print(instruction)
#     aircraft7.doing_current_instruction(instruction,0)
#     i=i+1
#     print(i)

##############三维图像###############
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

# plt.rcParams["font.family"]='Times New Roman'######全局字体
# plt.rcParams["font.size"]=10.5##########五号
# plt.rcParams["text.color"]='black'
# plt.rcParams["mathtext.fontset"]='stix'
# fig = plt.figure(figsize=(20,10))
# # fig = plt.figure(figsize=(16, 6))
# ax = fig.gca(projection='3d')
# # ax.axes.set_box_aspect((1,1,0.5)) # 设定坐标轴的长宽高比例
# # plt.gca().set_box_aspect((2, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
# # ax.set_aspect('equal','box')
# ax.set_box_aspect([1.18,0.5,1.05])
# # ax = fig.gca()
# font = {'family': 'SimSun',
#         'color':  'black',
#         'weight': 'normal',
#         'size': 10.5,
#         }#############x,y,z标签的字体
# # z_major_locator=MultipleLocator(0.3)
# #把x轴的刻度间隔设置为1，并存在变量里
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为10，并存在变量里
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# # ax.zaxis.set_major_locator(z_major_locator)
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
# ax.xaxis.set_major_formatter(FormatStrFormatter('%.00f'))
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.00f'))
# ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
# ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
# ax.zaxis._axinfo["grid"]['color'] = None##############x,y,z网格线颜色
# # ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
# ax.xaxis._axinfo["grid"]['color'] = None
# # ax.xaxis._axinfo["grid"]['linestyle'] = "-"
# ax.yaxis._axinfo["grid"]['color'] = None
# # ax.yaxis._axinfo["grid"]['linestyle'] = "-"

# ax.set_xlim(109,118)
# ax.set_ylim(21.5,25.5)
# ax.set_zlim(8.9,10.7)
# plt.title("Time = 2023-07-26 12:00:00",loc="center")
# ax.title('time = 2023-07-26')
# plt.axes.get_yaxis().set_visible(False)
# plt.axes.get_xaxis().set_visible(False)
# plt.axis('off')
def plotenv(ax):
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 8.9,'8.9')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.2,'9.2',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.5,'9.5',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 9.8,'9.8',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.1,'10.1',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.4,'10.4',color='blue')
    x = [114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85]
    y = [24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR01 = [list(zip(x,y,z))]
    AR01 =Poly3DCollection(AR01,facecolors='m',alpha=0.1)
    ax.add_collection3d(AR01)
    # ax.text(116.4, 23, 10.7,'10.7',color='blue')
    ###AR02
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x =[114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    x = [114.735,114.2,113.6433,113.54833,113.5633,113.634722,114.85,114.735]
    y =[24.29333,23.718333,23.92833,24.185,24.36555,25.20777,24.8,24.29333]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR02 = [list(zip(x,y,z))]
    AR02 =Poly3DCollection(AR02,facecolors='orange',alpha=0.1)
    ax.add_collection3d(AR02)
    ############################################################################################AR03
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    x = [113.5633,113.54833,113.6433,113.385,112.5333,112.796944,112.568889,113.42,113.56333]
    y =[24.36555,24.185,23.9283,23.535,23.40833,23.85083,24.4847222,24.3327778,24.365556]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR03 = [list(zip(x,y,z))]
    AR03 =Poly3DCollection(AR03,facecolors='green',alpha=0.1)
    ax.add_collection3d(AR03)
    #####################################################################ar04
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    x = [111.28,112.533,112.485277,112.48833,111.50833,110.785,110.55,110.185,111.266667,111.28]
    y =[24.355,23.4083,23.0713889,22.8,21.846666,22.46833,22.86,24.12833,24.148333,24.355]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR04 = [list(zip(x,y,z))]
    AR04 =Poly3DCollection(AR04,facecolors='brown',alpha=0.1)
    ax.add_collection3d(AR04)
    #############################################################################################ar06
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    x = [114.75,115.6667,116.3666,115.55,115.755,115.910278,114.4616667,114.18833,114.061667,114.46667,114.75,114.75]
    y =[22.4083,22.40833,22.6333,23.0833,23.31833,23.71583332,23.43334,23.256667,22.9,22.805,22.616667,22.4083]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR06 = [list(zip(x,y,z))]
    AR06 =Poly3DCollection(AR06,facecolors='royalblue',alpha=0.1)
    ax.add_collection3d(AR06)
    #########################################################################################AR05
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7,10.7]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4,10.4]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1,10.1]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8,9.8]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5,9.5]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2,9.2]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    x = [113.8666,113,113,112.48833,112.485277,112.5333,113.385,113.64333,114.2,114.32805,114.46167,114.18833,114.0616667,
        114.466667,114.75,114.75,114.5,114.486401,114.450001,114.345005,114.2116897,114.2092939,114.0203444,114.01944417,113.8506,113.848904,113.86667]
    y =[22.35833,21.6875,22.435,22.8,23.071389,23.40833,23.535,23.9280333,23.71833,23.64861,23.4333,23.256667,22.9,22.805,22.616667,22.40833,22.40833,
        22.4183461,22.52941694,22.578306,22.51959028,22.519111,22.4814147,22.48072,22.4316,22.429647,22.35833]
    z = [8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9,8.9]
    AR05 = [list(zip(x,y,z))]
    AR05 =Poly3DCollection(AR05,facecolors='blue',alpha=0.1)
    ax.add_collection3d(AR05)
    ax.view_init(28,270)

# xx=[];yy=[];zz=[]
# for i in aircraft7.tracklis:
#     xx.append(i[0])
#     yy.append(i[1])
#     zz.append(i[2]/1000)
# ax.plot(xx,yy,zz)

def getFutureTime(timestamp,it,format='%Y-%m-%d %H:%M:%S'):
    '''
    以给定时间戳为基准，前进 hours 个小时得到对应的时间戳
    '''
    now_time=datetime.datetime.strptime(timestamp,'%Y-%m-%d %H:%M:%S')
    for i in range(it):
        now_time+=datetime.timedelta(seconds=4)
    next_timestamp=now_time.strftime('%Y-%m-%d %H:%M:%S')
    # print ('next_timestamp: ',next_timestamp)
    return next_timestamp
timestamp='2023-07-23 09:00:00'
stamplis=[]
for i in range(900):
    tt=getFutureTime(timestamp, it=i, format='%Y-%m-%d %H:%M:%S')
    stamplis.append(tt)

from generate_track_basedon_critical_points import get_next_track_point,get_instruction,get_next_track4,get_heading
from multi_cb_conflicts_resolve import get_c_lis
finalAlis=[]
ccc=[]
ddd=[]

    
    
Alis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7,aircraft8,aircraft9,aircraft10,aircraft11,aircraft12,aircraft13,aircraft14,aircraft15,aircraft16,aircraft20,aircraft21,
       aircraft22,aircraft23,aircraft24,aircraft25,aircraft27,aircraft28,aircraft29,aircraft31,aircraft4c,aircraft5c,aircraft6c,aircraft7c]
# Alis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7,aircraft8,aircraft9,aircraft15]
#       ]
for craft in Alis:
    craft.get_change_instruction(instruction=0)
# for t in range(1,388):   

orglis=[[114,23.1,0.3],[111.5,23.5,0.4],[115.5,23.5,0.2]]
vlis=[]
for i in range(len(stamplis)):
    vx=-0.0005;vy=0.0002
    vx=vx+np.random.normal(0,0.00015)
    vy=vy+np.random.normal(0,0.000055)
    vlis.append([vx,vy])
bigcloudlis=[]
for i in range(len(vlis)):
    newlisi=[]
    for j in range(len(orglis)):
        orglis[j][0]=orglis[j][0]+vlis[i][0]
        orglis[j][1]=orglis[j][1]+vlis[i][1]
        newlisi.append([orglis[j][0],orglis[j][1],orglis[j][2]])
    bigcloudlis.append(newlisi)
for t in range(len(stamplis)):
# for t in range(230):
    print(t)
    # cloudlis=[[114,23.1,0.3],[111.5,23.5,0.4],[113.5,23.5,0.2]]
    cloudlis=bigcloudlis[t]
    ##################每个时间戳加入航空器##########
    # conflictlisDic=get_conflict_dic(Alis)
    # print(conflictlisDic)
    conflictpairdic=agent_control(Alis)
    ccc.append(conflictpairdic)
    for craft in Alis:
        mid_process(craft)
    # altitudeadj=get_altD9c(craftlis=Alis,conflictlisDic=conflictlisDic)
    # ddd.append(altitudeadj)
    # print(altitudeadj)
    # Alis=[aircraft1,aircraft15]
    # Alis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7,aircraft8,aircraft9,aircraft10,aircraft11,aircraft12,aircraft13,aircraft14,aircraft15,aircraft16,aircraft20,aircraft21,
    #       aircraft22,aircraft23,aircraft24,aircraft25,aircraft27,aircraft28,aircraft29,aircraft31,aircraft4c,aircraft5c,aircraft6c,aircraft7c]
    ###################计算未来几个关键航迹点(比如：4个)################
    for craft in Alis:
        critical_tralis=craft.flightplan
        i_t= get_c_lis(cloudlis,critical_tralis)  
        if i_t == 'diversion':
            # print('diversion'+craft.callsign)
            Alis.remove(craft)
            # finalAlis.append(craft)
            continue
        else:
            craft.add_critical_track_points(i_t)
        next_point = get_next_track_point(current_point=craft.current_position,tracklis=craft.critical_track_points,v=craft.current_v,height=craft.height)
        if next_point == 'arrive':
            Alis.remove(craft)
            finalAlis.append(craft)
            continue
        
        elif next_point=='abnormal':
            next_point=[craft.critical_track_points[-1][0],craft.critical_track_points[-1][1]]
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point,aircraft=craft,dicttoavoid=conflictpairdic)
        else:
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point['point0'],aircraft=craft,dicttoavoid=conflictpairdic)
        # print('Alisnum')
        # for i in Alis:
        #     print(i.callsign)
        # if craft == aircraft1:
        #     print(instruction)
            # print(instruction)
        # if t == 350:
        #     instruction={'speed':1050,'flightlevel':10400,'heading':60,'timeinterval':4}
        # if instruction['flightlevel'] != 9800:
        #     print('vnaeuirvhnsdfkjvnreiuvhreknsfdvnaeuirvhnsdfkjvnreiuvhreknsfdvnaeuirvhnsdfkjvnreiuvhreknsfd')'
        # craft.get_change_instruction(instruction)
        craft.get_change_instruction(instruction)
        # print(craft.instruction)
        craft.doing_current_instruction(craft.instruction,stamplis[t])
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts

def iconPlan(iconMat,height,dx,dy,rotangle):

    iconMat=rot(iconMat, rotangle)
    x=[]
    y=[]
    z=[]

    for i in range(iconMat.shape[0]):
        x.append(iconMat[i,0]+dx)
        y.append(iconMat[i,1]+dy)
        z.append(height)
    newicon=[list(zip(x,y,z))]
    return newicon
def plotcraft(aircraft,time,ax,cc):
    xx=[];yy=[];zz=[];hh=[]
    for i in range(1,time):
        xx.append(aircraft.tracklis[i][0])
        yy.append(aircraft.tracklis[i][1])
        zz.append(aircraft.tracklis[i][2]/1000)
        hh.append(aircraft.tracklis[i][3])
    if len(xx)>=4:
        # ax.plot(xx,yy, zz, color=cc)
        ax.plot(xx[-4::],yy[-4::], zz[-4::], color=cc)
        iconMat = 0.01*np.array([[0, 9],[1,8],
         			[1, 2],
         			[7, -3],
         			[7, -6],
         			[1, -3],
                    [1,-9],
                    [3,-9.5],
                    [3,-10.8],
                    [0.3,-10],
                    [0,-12],
                    [-0.3,-10],[-3,-10.5],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])
        # print(zz)
        # print(xx)
        # print(hh)
        aircrafticon = iconPlan(iconMat=iconMat,height=zz[-1],dx=xx[-1],dy=yy[-1],rotangle=hh[-1])
        aircrafticon =Poly3DCollection(aircrafticon,facecolors='m',alpha=0.8)
        ax.add_collection3d(aircrafticon)
    else:
        ax.plot(xx,yy, zz, color=cc)
    
def elicipse(x,y,z,rx,ry,rz,ax):
    u=np.linspace(0,2*np.pi,20)
    v=np.linspace(0,2*np.pi,20)
    x=rx*np.outer(np.cos(u),np.sin(v))+x
    y=ry*np.outer(np.sin(u),np.sin(v))+y
    z=rz*np.outer(np.ones(np.size(u)),np.cos(v))+z
    ax.plot_surface(x, y, z, cmap='summer',alpha=0.3)
def cylinder(x,y,r,h_min,h,ax):
    # elicipse(x,y,z=h+h_min,rx=r,ry=r,rz=0.000001)
    # elicipse(x,y,z=h_min,rx=r,ry=r,rz=0.000001)
    u = np.linspace(0,2*np.pi,50)  # 把圆分按角度为50等分
    h = np.linspace(0,h,20)         # 把高度1均分为20份####圆柱高
    # th_center
    x =(r)*np.outer(np.sin(u),np.ones(len(h)))+x  # x值重复20次
    y =(r)*np.outer(np.cos(u),np.ones(len(h)))+y # y值重复20次
    z = np.outer(np.ones(len(u)),h)+h_min   # x，y 对应的高度,#底座高
    ax.plot_surface(x, y, z, cmap='autumn',alpha=0.2)
# plt.savefig('test', dpi=800, facecolor='w', edgecolor='w' papertype=None, transparent=False, bbox_inches=None, pad_inches=0.1, frameon=None, metadata=None)

from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import make_interp_spline
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=14.5##########五号
plt.rcParams["text.color"]='black'
plt.rcParams["mathtext.fontset"]='stix'
fig = plt.figure(figsize=(20,10))
# fig = plt.figure(figsize=(16, 6))
ax = fig.gca(projection='3d')
# ax.axes.set_box_aspect((1,1,0.5)) # 设定坐标轴的长宽高比例
# plt.gca().set_box_aspect((2, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
# ax.set_aspect('equal','box')
ax.set_box_aspect([1.5,0.5,1.05])
# ax = fig.gca()
font = {'family': 'SimSun',
        'color':  'black',
        'weight': 'normal',
        'size': 14.5,
        }#############x,y,z标签的字体
# z_major_locator=MultipleLocator(0.3)
#把x轴的刻度间隔设置为1，并存在变量里
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为10，并存在变量里
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
# ax.zaxis.set_major_locator(z_major_locator)
ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
ax.xaxis.set_major_formatter(FormatStrFormatter('%.00f'))
ax.yaxis.set_major_formatter(FormatStrFormatter('%.00f'))
ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
ax.zaxis._axinfo["grid"]['color'] = None##############x,y,z网格线颜色
# ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
ax.xaxis._axinfo["grid"]['color'] = None
# ax.xaxis._axinfo["grid"]['linestyle'] = "-"
ax.yaxis._axinfo["grid"]['color'] = None
# ax.yaxis._axinfo["grid"]['linestyle'] = "-"
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.pyplot as plt
ax.set_xlim(109,118)
ax.set_ylim(21.5,25.5)
ax.set_zlim(8.9,10.7)
# plt.title("Time = 2023-07-26 12:00:00",loc="center")
plotenv(ax)
# cylinder(114,23.1,0.3,8.9,1.8,ax)    
# cylinder(111.5,23.5,0.4,8.9,1.8,ax) 
# cylinder(113.5,23.5,0.2,8.9,1.8,ax) 
def plot_track(aircraft,ax):
    x=[];y=[];z=[]
    for i in aircraft.tracklis:
        x.append(i[0])
        y.append(i[1])
        z.append(i[2]/1000)
    ax.plot(x,y,z,color='green',alpha=0.3)
ax.set_xlabel('Longitude($^o$)')
ax.set_ylabel('Latitude($^o$)')
ax.set_zlabel('Altitude(km)')

# plotenv(ax)
# plot_track(aircraft1,ax)
# plot_track(aircraft2,ax)
# plot_track(aircraft3,ax)
# plot_track(aircraft4,ax)
# plot_track(aircraft5,ax)
# plot_track(aircraft6,ax)
# plot_track(aircraft7,ax)
# plot_track(aircraft8,ax)
# plot_track(aircraft15,ax)

# dlis=[]
# for i in range(len(aircraft1.tracklis)):
#     dis=(aircraft1.tracklis[i][0]-aircraft15.tracklis[i][0])**2+(aircraft1.tracklis[i][1]-aircraft15.tracklis[i][1])**2
#     dlis.append(dis)
# plotcraft(aircraft1,len(aircraft1.tracklis),ax,cc='red')
# plotcraft(aircraft2,len(aircraft2.tracklis),ax,cc='red')
# plotcraft(aircraft3,len(aircraft3.tracklis),ax,cc='red')
# plotcraft(aircraft4,len(aircraft4.tracklis),ax,cc='red')
# plotcraft(aircraft5,len(aircraft5.tracklis),ax,cc='red')
# plotcraft(aircraft6,len(aircraft6.tracklis),ax,cc='red')
# plotcraft(aircraft7,len(aircraft7.tracklis),ax,cc='red')
# plotcraft(aircraft8,len(aircraft8.tracklis),ax,cc='red')
# plotcraft(aircraft9,len(aircraft9.tracklis),ax,cc='red')
# plotcraft(aircraft10,len(aircraft10.tracklis),ax,cc='red')

# ###############################制作gif动画测试################
# # plt.savefig(f"{1}.png")

# plt.savefig('6.png', dpi=700, facecolor=None, edgecolor=None,
#           orientation='portrait', papertype=None, format=None,
#           transparent=False, bbox_inches=None, pad_inches=0.1,
#           frameon=None, metadata=None)

# frames=6
# from PIL import Image
# images = [Image.open(f"{n}.png") for n in range(1,frames)]

# images[0].save('simulation2.gif', save_all=True, append_images=images[1:], duration=300, loop=0)
# plt.legend()




# x=[0,1,1,7,7,1,1,3,3,0.3,0,-0.3,-3,-3,-1,-1,-7,-7,-1,-1,0]
# y=[9,8,2,-3,-6,-3,-9,-9.5,-10.5,-10,-12,-10,-10.8,-9.5,-9,-3,-6,-3,2,8,9]
# z = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
# ax.set_xlim(-20,20)
# ax.set_ylim(-20,20)
# ax.set_zlim(-5,5)
import pandas as pd
import numpy as np
def plotairroutes(ax):
    airroute1=np.array(pd.read_csv('airway1.csv')).T
    airroute2=np.array(pd.read_csv('airway2.csv')).T
    airroute3=np.array(pd.read_csv('airway3.csv')).T
    airroute4=np.array(pd.read_csv('airway4.csv')).T
    airroute5=np.array(pd.read_csv('airway5.csv')).T
    airroute6=np.array(pd.read_csv('airway6.csv')).T
    x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,12):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute1[i,0]))):
            if 109<=eval(airroute1[i,0])[j][0]<=118 and 21<=eval(airroute1[i,0])[j][1]<=25.5:
                x.append(eval(airroute1[i,0])[j][0])
                y.append(eval(airroute1[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
                
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,11):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute2[i,0]))):
            if 109<=eval(airroute2[i,0])[j][0]<=118 and 21<=eval(airroute2[i,0])[j][1]<=25.5:
                x.append(eval(airroute2[i,0])[j][0])
                y.append(eval(airroute2[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
                
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,11):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute3[i,0]))):
            if 109<=eval(airroute3[i,0])[j][0]<=118 and 21<=eval(airroute3[i,0])[j][1]<=25.5:
                x.append(eval(airroute3[i,0])[j][0])
                y.append(eval(airroute3[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.9,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.9,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.9,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,13):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute4[i,0]))):
            if 109<=eval(airroute4[i,0])[j][0]<=118 and 21<=eval(airroute4[i,0])[j][1]<=25.5:
                x.append(eval(airroute4[i,0])[j][0])
                y.append(eval(airroute4[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor=None,markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,56):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute5[i,0]))):
            if 109<=eval(airroute5[i,0])[j][0]<=118 and 21<=eval(airroute5[i,0])[j][1]<=25.5:
                x.append(eval(airroute5[i,0])[j][0])
                y.append(eval(airroute5[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
    for i in range(1,13):
        # print(len(eval(airroute1[i,0])))
        for j in range(len(eval(airroute6[i,0]))):
            if 109<=eval(airroute6[i,0])[j][0]<=118 and 21<=eval(airroute6[i,0])[j][1]<=25.5:
                x.append(eval(airroute6[i,0])[j][0])
                y.append(eval(airroute6[i,0])[j][1])
                z.append(8.9)
                z1.append(9.8)
                z2.append(10.7)
        ax.plot(x,y,z,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z1,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        ax.plot(x,y,z2,marker='^', color='deepskyblue', markersize=2,markerfacecolor='mediumblue',markeredgecolor=None,linewidth=0.7,alpha=0.1)
        x=[];y=[];z=[];z1=[];z2=[]
# plt.plot([14,15],[5,9],[5,7],linewidth=1,color='black',alpha=0.3)
plotairroutes(ax)
plt.savefig('33333.png', dpi=600, facecolor=None, edgecolor=None,
          orientation='portrait', papertype=None, format=None,
          transparent=False, bbox_inches=None, pad_inches=0.1,
          frameon=None, metadata=None)

def animation(numberofpci,interval):
    for i in range(numberofpci):
        print(i)
        from mpl_toolkits.mplot3d import Axes3D
        from matplotlib import cm
        from matplotlib.ticker import LinearLocator, FormatStrFormatter
        from matplotlib.ticker import MultipleLocator
        from scipy.interpolate import make_interp_spline
        import numpy as np
        import matplotlib.pyplot as plt
        
        plt.rcParams["font.family"]='Times New Roman'######全局字体
        plt.rcParams["font.size"]=10.5##########五号
        plt.rcParams["text.color"]='black'
        plt.rcParams["mathtext.fontset"]='stix'
        fig = plt.figure(figsize=(20,10))
        # fig = plt.figure(figsize=(16, 6))
        ax = fig.gca(projection='3d')
        # ax.axes.set_box_aspect((1,1,0.5)) # 设定坐标轴的长宽高比例
        # plt.gca().set_box_aspect((2, 1, 0.5))  # 当x、y、z轴范围之比为3:5:2时。
        # ax.set_aspect('equal','box')
        ax.set_box_aspect([1.18,0.5,1.05])
        
        # ax = fig.gca()
        font = {'family': 'SimSun',
                'color':  'black',
                'weight': 'normal',
                'size': 10.5,
                }#############x,y,z标签的字体
        # z_major_locator=MultipleLocator(0.3)
        #把x轴的刻度间隔设置为1，并存在变量里
        x_major_locator=MultipleLocator(1)
        #把x轴的刻度间隔设置为1，并存在变量里
        y_major_locator=MultipleLocator(1)
        #把y轴的刻度间隔设置为10，并存在变量里
        ax.xaxis.set_major_locator(x_major_locator)
        #把x轴的主刻度设置为1的倍数
        ax.yaxis.set_major_locator(y_major_locator)
        # ax.zaxis.set_major_locator(z_major_locator)
        ax.zaxis.set_major_formatter(FormatStrFormatter('%.01f'))##########保留x,y,z坐标小数位数
        ax.xaxis.set_major_formatter(FormatStrFormatter('%.00f'))
        ax.yaxis.set_major_formatter(FormatStrFormatter('%.00f'))
        ax.xaxis._axinfo["grid"]['linewidth'] = 0.1##########x,y,z网格线粗细
        ax.yaxis._axinfo["grid"]['linewidth'] = 0.1
        ax.zaxis._axinfo["grid"]['linewidth'] = 0.1
        ax.zaxis._axinfo["grid"]['color'] = None##############x,y,z网格线颜色
        # ax.zaxis._axinfo["grid"]['linestyle'] = "-"##############x,y,z网格线线型
        ax.xaxis._axinfo["grid"]['color'] = None
        # ax.xaxis._axinfo["grid"]['linestyle'] = "-"
        ax.yaxis._axinfo["grid"]['color'] = None
        # ax.yaxis._axinfo["grid"]['linestyle'] = "-"
        from mpl_toolkits.mplot3d import Axes3D
        from mpl_toolkits.mplot3d.art3d import Poly3DCollection
        import matplotlib.pyplot as plt
        ax.set_xlim(109,118)
        ax.set_ylim(21.5,25.5)
        ax.set_zlim(8.9,10.7)
        
        plotairroutes(ax)
        plt.title(stamplis[i*interval],loc="center")
        plotenv(ax)
        cylinder(bigcloudlis[i*interval][0][0],bigcloudlis[i*interval][0][1],bigcloudlis[i*interval][0][2],8.9,1.8,ax)    
        cylinder(bigcloudlis[i*interval][1][0],bigcloudlis[i*interval][1][1],bigcloudlis[i*interval][1][2],8.9,1.8,ax) 
        cylinder(bigcloudlis[i*interval][2][0],bigcloudlis[i*interval][2][1],bigcloudlis[i*interval][2][2],8.9,1.8,ax) 
        print(i)
        if len(aircraft1.tracklis)>=i*interval:
            # print('asfsafesgf')
            plotcraft(aircraft1,i*interval,ax,'red')
            
        if len(aircraft2.tracklis)>=i*interval:
            plotcraft(aircraft2,i*interval,ax,'blue')    
        if len(aircraft3.tracklis)>=i*interval:
            plotcraft(aircraft3,i*interval,ax,'green')  
        if len(aircraft4.tracklis)>=i*interval:
            # print('ss')
            plotcraft(aircraft4,i*interval,ax,'gray')  
        if len(aircraft5.tracklis)>=i*interval:
            plotcraft(aircraft5,i*interval,ax,'orange')  
        if len(aircraft6.tracklis)>=i*interval:
            plotcraft(aircraft6,i*interval,ax,'yellow')  
        if len(aircraft7.tracklis)>=i*interval:
            plotcraft(aircraft7,i*interval,ax,'purple')  
        if len(aircraft8.tracklis)>=i*interval:
            plotcraft(aircraft8,i*interval,ax,'black' ) 
        if len(aircraft9.tracklis)>=i*interval:
            plotcraft(aircraft9,i*interval,ax,'lime')  
        if len(aircraft10.tracklis)>=i*interval:
            plotcraft(aircraft10,i*interval,ax,'green')  
        if len(aircraft11.tracklis)>=i*interval:
            plotcraft(aircraft11,i*interval,ax,'purple')  
        if len(aircraft12.tracklis)>=i*interval:
            plotcraft(aircraft12,i*interval,ax,'lime')  
        if len(aircraft13.tracklis)>=i*interval:
            plotcraft(aircraft13,i*interval,ax,'blue')  
        if len(aircraft14.tracklis)>=i*interval:
            plotcraft(aircraft14,i*interval,ax,'red')  
            
        if len(aircraft15.tracklis)>=i*interval:
            plotcraft(aircraft15,i*interval,ax,'blue') 
        if len(aircraft20.tracklis)>=i*interval:
            plotcraft(aircraft20,i*interval,ax,'red')
        if len(aircraft21.tracklis)>=i*interval:
            plotcraft(aircraft21,i*interval,ax,'blue')    
        if len(aircraft27.tracklis)>=i*interval:
            plotcraft(aircraft27,i*interval,ax,'green')  
        if len(aircraft28.tracklis)>=i*interval:
            plotcraft(aircraft28,i*interval,ax,'gray')  
        if len(aircraft29.tracklis)>=i*interval:
            plotcraft(aircraft29,i*interval,ax,'orange')  
        if len(aircraft22.tracklis)>=i*interval:
            plotcraft(aircraft22,i*interval,ax,'blue')    
        if len(aircraft23.tracklis)>=i*interval:
            plotcraft(aircraft23,i*interval,ax,'green')  
        if len(aircraft24.tracklis)>=i*interval:
            plotcraft(aircraft24,i*interval,ax,'gray')  
        if len(aircraft25.tracklis)>=i*interval:
            plotcraft(aircraft25,i*interval,ax,'orange')  
        # if len(aircraft30.tracklis)>=i*interval:
        #     plotcraft(aircraft30,i*interval,ax,'yellow')  
        if len(aircraft31.tracklis)>=i*interval:
            plotcraft(aircraft31,i*interval,ax,'yellow')  
        if len(aircraft4c.tracklis)>=i*interval:
            plotcraft(aircraft4c,i*interval,ax,'yellow')  
        if len(aircraft5c.tracklis)>=i*interval:
            plotcraft(aircraft5c,i*interval,ax,'yellow')  
        if len(aircraft6c.tracklis)>=i*interval:
            plotcraft(aircraft6c,i*interval,ax,'gray')  
        if len(aircraft7c.tracklis)>=i*interval:
            plotcraft(aircraft7c,i*interval,ax,'orange') 
        plot_track(aircraft1,ax)
        plot_track(aircraft2,ax)
        plot_track(aircraft3,ax)
        plot_track(aircraft4,ax)
        plot_track(aircraft5,ax)
        plot_track(aircraft6,ax)
        plot_track(aircraft7,ax)
        plot_track(aircraft8,ax)
        plot_track(aircraft9,ax)
        plot_track(aircraft10,ax)
        plot_track(aircraft11,ax)
        plot_track(aircraft12,ax)
        plot_track(aircraft13,ax)
        plot_track(aircraft14,ax)
        # plot_track(aircraft9,ax)
        plot_track(aircraft15,ax)
        plot_track(aircraft20,ax)
        plot_track(aircraft21,ax)
        plot_track(aircraft22,ax)
        plot_track(aircraft23,ax)
        plot_track(aircraft24,ax)
        plot_track(aircraft25,ax)
        plot_track(aircraft27,ax)
        plot_track(aircraft28,ax)
        plot_track(aircraft29,ax)
        # plot_track(aircraft30,ax)
        plot_track(aircraft31,ax)
        plot_track(aircraft4c,ax)
        plot_track(aircraft5c,ax)
        plot_track(aircraft6c,ax)
        plot_track(aircraft7c,ax)
        plt.savefig(str(i)+'.png', dpi=300, facecolor=None, edgecolor=None,
                  orientation='portrait', papertype=None, format=None,
                  transparent=False, bbox_inches=None, pad_inches=0.1,
                  frameon=None, metadata=None)


    frames=numberofpci
    from PIL import Image
    images = [Image.open(f"{n}.png") for n in range(0,frames)]
    images[0].save('simulation3.gif', save_all=True, append_images=images[1:], duration=300, loop=0)
    # plt.legend()


animation(numberofpci=40,interval=15)
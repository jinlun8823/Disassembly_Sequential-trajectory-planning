from matplotlib.path import Path
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
fig = plt.figure()
ax = fig.gca(projection='3d')

def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts

def iconPlan(iconMat,height,dx,dy,rotangle):

    iconMat=rot(iconMat, rotangle)
    x=[]
    y=[]
    z=[]

    for i in range(iconMat.shape[0]):
        x.append(iconMat[i,0]+dx)
        y.append(iconMat[i,1]+dy)
        z.append(height)
    newicon=[list(zip(x,y,z))]
    return newicon
# x=[0,1,1,7,7,1,1,3,3,0.3,0,-0.3,-3,-3,-1,-1,-7,-7,-1,-1,0]
# y=[9,8,2,-3,-6,-3,-9,-9.5,-10.5,-10,-12,-10,-10.8,-9.5,-9,-3,-6,-3,2,8,9]
# z = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
ax.set_xlim(-20,20)
ax.set_ylim(-20,20)
ax.set_zlim(-5,5)
iconMat = 0.5*np.array([[0, 9],[1,8],
			[1, 2],
			[7, -3],
			[7, -6],
			[1, -3],
            [1,-9],
            [3,-9.5],
            [3,-10.8],
            [0.3,-10],
            [0,-12],
            [-0.3,-10],[-3,-10.5],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])
aircrafticon = iconPlan(iconMat=iconMat,height=5,dx=14,dy=5,rotangle=180)
aircrafticon =Poly3DCollection(aircrafticon,facecolors='m',alpha=0.8)
ax.add_collection3d(aircrafticon)
t='B737'

ax.text(15,9,7,t,bbox=dict(boxstyle='round,pad=0.5', fc='yellow', ec='k',lw=1 ,alpha=0.1))
# ax.scatter(14,5,5)
plt.plot([14,15],[5,9],[5,7],linewidth=1,color='black',alpha=0.3)







# iconMat = 100*np.array([[0, 9,0],[1,8,0],
# 			[1, 2,0],
# 			[7, -3,0],
# 			[7, -6,0],
# 			[1, -3,0],
#             [1,-9,0],
#             [3,-9.5,0],
#             [3,-10.8,0],
#             [0.3,-10,0],
#             [0,-12,0],
#             [-0.3,-10,0],[-3,-10.8,0],[-3,-9.5,0],[-1,-9,0],[-1,-3,0],[-7,-6,0],[-7,-3,0],[-1,2,0],[-1,8,0],[0,9,0]])

# class CustomMarker1(Path):
#     def __init__(self, icon, az):
#          if icon == "icon": 
#              verts = iconMat  
#          vertices = rot(verts, az)  
#          super().__init__(vertices)
# plt.rcParams["font.family"]='Times New Roman'######全局字体
# plt.rcParams["font.size"]=18.5##########五号
# plt.rcParams["text.color"]='black'
# plt.rcParams["mathtext.fontset"]='stix'
# fig = plt.figure()
# ax = fig.gca(projection='3d')      
# ax.scatter(10, 10, 30, marker=CustomMarker1("icon", 60), c="red", s=250)
# ax.scatter(10, 10, 50, marker=''CustomMarker1("icon", 60)'', c="red", s=250)
from judge_intersection import calculate_intersection_point,judge_same_way
from generate_track_basedon_critical_points import get_heading
import random
class Aircraft:######航空器类
    def __init__(self,callsign='',crafttype='B737',flightplan=[],critical_track_points=[],current_position=[],nine_critical_position=[],
                eight_minute_predicted_position=[], current_v=1000, height=9800,heading=0,tracklis=[]):##Aircraft属性
        self.callsign=callsign
        self.crafttype=crafttype
        self.flightplan=flightplan
        self.current_position=current_position
        self.nine_critical_position=nine_critical_position
        self.eight_minute_predicted_position=eight_minute_predicted_position
        self.current_v=current_v
        self.height=height
        self.critical_track_points=critical_track_points###未来的9个关键航路点
        self.heading=heading
        # self.Value=callsign
        self.tracklis=[[current_position[0],current_position[1],self.height]]
    def add_nine_critical_position(self,nine_critical_position):
        self.nine_critical_position=nine_critical_position
    def add_four_critical_position(self,four_critical_position):
        self.four_critical_position=four_critical_position
    def add_two_critical_position(self,two_critical_position):
        self.two_critical_position=two_critical_position
    def get_next_intention(self,two_critical_position,current_position):
        intention=two_critical_position[0]['point1']
        # if len(two_critical_position)>=2:
        #     # if ((two_critical_position[0]['point0'][0]-current_position[0])**2+(two_critical_position[0]['point0'][1]-current_position[1])**2)**(1/2)<0.00528:
        #         intention=two_critical_position[1]['point2']
        #     # else:
        #     #     intention=two_critical_position[1]['point1']
        # else:
        #     intention=two_critical_position[0]['point1']
        self.intention=intention
        return intention
    def get_heading(self):
        A=self.current_position
        B=self.intention
        heading=get_heading(A,B)
        self.heading=heading
    def doing_current_instruction(self,instruction,timestamp):
        speed=instruction['speed']
        heading=instruction['heading']
        flightlevel=instruction['flightlevel']
        timeinterval=instruction['timeinterval']
        self.current_v=speed
        self.heading=heading
        x = self.current_position[0]+timeinterval*(self.current_v/(3600*110))*np.cos(np.pi/2-(self.heading*2*np.pi/360))
        y = self.current_position[1]+timeinterval*(self.current_v/(3600*110))*np.sin(np.pi/2-(self.heading*2*np.pi/360))
        self.current_position = [x,y]
        
        if self.height < flightlevel:
            print(self.callsign)
            z = self.height+timeinterval*7.6
            if z >= flightlevel:
                z=flightlevel
        elif self.height > flightlevel:
            # print('y')
            z = self.height-timeinterval*7.6
            if z <= flightlevel:
                z=flightlevel
        else:
            z=flightlevel
        self.height=z
        self.tracklis.append([self.current_position[0],self.current_position[1],self.height,self.heading,timestamp])

        # return next_position
    def add_critical_track_points(self,critical_track_points):##航空器所有关键航路点
        self.critical_track_points=critical_track_points
    def add_eight_minute_predicted_position(self,eight_minute_predicted_position):####未来一段时间的点迹
        self.eight_minute_predicted_position=eight_minute_predicted_position
    def add_airspaceNearby(self,airspaceNearby):
        self.airspaceNearby=airspaceNearby
    def flight_level_classify_m(self,height):
        levellis=[11600,11300,11000,10700,10400,10100,9800,9500,9200,8900,8400,8100,7800,7500,7200,6900,6600,6300,6000,5700,5400]
        for hh in range(len(levellis)-1):
            if levellis[hh+1]<=height<levellis[hh]:
                if levellis[hh]-height<=height-levellis[hh+1]:
                    self.flightlevelm=levellis[hh]
                else:
                    self.flightlevelm=levellis[hh+1]
    def flight_level_classify_ft(self,height):
        levellis=[38100,37100,36100,35100,34100,33100,32100,31100,30100,29100,27600,26600,25600,24600,23600,22600,21700,20700,19700,18700,17700]
        for hh in range(len(levellis)-1):
            if levellis[hh+1]<=height<levellis[hh]:
                if levellis[hh]-height<=height-levellis[hh+1]:
                    self.flightlevelft=levellis[hh]
                else:
                    self.flightlevelft=levellis[hh+1]
    # def judge_same_way_now(aircraftSet,thisAircraft):
        
    def judge_conflicts(self,aircraftSet,thisAircraft):#####aircraftSet:空域中所有的航空器####
        ##同高度层50km内是否有飞机，若无，则无冲突，若有，进入下一步
        ###其他飞机与本飞机有无交叉点，若无则无冲突，若有，进入下一步
        ###
        aircraftSetc=aircraftSet.copy()
        conflicts_dic={'same_point':[],'same_way':[]}
        aircraftSetc.remove(thisAircraft)
        for i in aircraftSetc:
            if i.flightlevelm == thisAircraft.flightlevelm and (i.current_position[0]-thisAircraft.current_position[0])**2+(i.current_position[1]-thisAircraft.current_position[1])**2 < 1:####100km
                #####判断未来1个航迹点构成的线段是否与周围的飞机有冲突
                a=thisAircraft.intention
                b=i.intention
                kk=judge_same_way(x1=thisAircraft.current_position[0],y1=thisAircraft.current_position[1],
                                  x2=a[0],y2=a[1],
                                  x3=i.current_position[0],y3=i.current_position[1],
                                  x4=b[0],y4=b[1])
                if type(kk) == list:
                    conflicts_dic['same_way'].append(i)
                elif (a[0]-b[0])**2+(a[1]-b[1])**2 <0.0081: 
                    conflicts_dic['same_point'].append(i)
                else:#没有冲突
                    continue
            else:#没有冲突
                continue
        return conflicts_dic#####返回具有存在冲突/潜在冲突的航空器
    
    def get_flight_level_available(self,aircraftSet,thisAircraft):
        aircraftSetc=aircraftSet.copy()
        aircraftSetc.remove(thisAircraft)
        if 0 <= thisAircraft.heading <= 180:
            levellis = [10700,10100,9500,8900,10400,9800,9200]
        else:
            levellis = [10400,9800,9200,10700,10100,9500,8900]
        print(thisAircraft.flightlevelm)
        # print(thisAircraft.heading)
        ii=levellis.index(thisAircraft.flightlevelm)
        # print(ii)
        if ii == 0 :
            # print('0')
            level_available  = [levellis[ii+1]]
        elif ii == len(levellis)-1:
            # print('1')
            level_available  = [levellis[ii-1]]
        else:
            # print('2')
            level_available  = [levellis[ii-1],levellis[ii+1]]
        for i in aircraftSetc:
            if (i.current_position[0]-thisAircraft.current_position[0])**2+(i.current_position[1]-thisAircraft.current_position[1])**2 < 0.07436:###30km
                if i.flightlevelm in level_available:
                    level_available.remove(i.flightlevelm)
                else:
                    continue
            else:
                continue
        if level_available == []:
            level_available= ['nonlevelcanused']
        return level_available       
    def get_change_instruction(self,instruction):
        ini_instruction={'speed':1000,'flightlevel':self.height,'heading':333,'timeinterval':4}
        if instruction == 0:
            self.instruction = ini_instruction
        else:
            # self.instruction = instruction
            if instruction['speed'] != None:
                self.instruction['speed']  = instruction['speed']
            if instruction['flightlevel'] != None:
                self.instruction['flightlevel']  = instruction['flightlevel']
            if instruction['heading'] != None:
                self.instruction['heading']  = instruction['heading']
            
        
        
    # def doing_current_instruction(self,instruction):###根据获得航向、速度、高度获得状态转移，instruction:[速度，航向，高度，粒度]
    #     self.get_next_position(speed=instruction['speed'],heading=instruction['heading'],flightlevel=instruction['flightlevel'],timeinterval=instruction['timeinterval'])
        
        
        
        
        
    # def get_instruction(self,criticaltracklis):######获得instruction
        
        
        
    # def statetransform(self,)
# class airspaceNearby:#######附近的空域,返回该航空器周边可用的高度层
#     def __init__(self, aircraftSet,thisAircraft):
        
    
#     def get_nearby_Aircraft():    
    
    
#     def get_available_flight_level():
import numpy as np
def speed_adjust_intersection(aircraft1,aircraft2):
    A1_intention=aircraft1.intention
    position1=aircraft1.current_position
    D1=((A1_intention[0]-position1[0])**2+(A1_intention[1]-position1[1])**2)**(1/2)
    A2_intention=aircraft2.intention
    position2=aircraft2.current_position
    D2=((A2_intention[0]-position2[0])**2+(A2_intention[1]-position2[1])**2)**(1/2)
    v1=aircraft1.current_v/(110*3600)
    v2=aircraft2.current_v/(110*3600)
    p1=[A1_intention[0]-position1[0],A1_intention[1]-position1[1]]
    p2=[A2_intention[0]-position2[0],A2_intention[1]-position2[1]]
    cosxita=(p1[0]*p2[0]+p1[1]*p2[1])/(((p1[0]**2+p1[1]**2)**(1/2))*((p2[0]**2+p2[1]**2)**(1/2)))
    xita=np.arccos(cosxita)*180/np.pi
    lamda=(D1*v1 - D1*v2*cosxita - D2*v1*cosxita + D2*v2)/(v1**2 - 2*v1*v2*cosxita + v2**2)
    d2=(D1 - v1*lamda)**2 - (2*D1 - 2*v1*lamda)*(D2 - v2*lamda)*cosxita + (D2 - v2*lamda)**2
    d=d2**(1/2)
    deltav = 0
    if d > 0.1:
        return deltav*110*3600
    else:
        time=1
        while d <=0.1 and time <10:
            if D1 >= D2:
                v1=v1-deltav
                v2=v2+deltav
            else:
                v1=v1+deltav
                v2=v2-deltav
            lamda=(D1*v1 - D1*v2*cosxita - D2*v1*cosxita + D2*v2)/(v1**2 - 2*v1*v2*cosxita + v2**2)
            d2=(D1 - v1*lamda)**2 - (2*D1 - 2*v1*lamda)*(D2 - v2*lamda)*cosxita + (D2 - v2*lamda)**2
            d=d2**(1/2)
            deltav+=18.52/(110*3600)
            time+=1
    return deltav*110*3600

def speed_adjust_sameway(aircraft,samewayAircraftlis):###samewayAircraftlis直接就是同航路的aircraft列表，而不是空域所有的aircraft
    samewayAircraftliscopy=samewayAircraftlis.copy()
    samewayAircraftliscopy.append(aircraft)
    
    disdict = {}  
    for craft in samewayAircraftliscopy:
        disdict[craft] = (craft.current_position[1] - craft.intention[1])**2 + (craft.current_position[1] - craft.intention[1])**2
    dislis = sorted(disdict.items(),key = lambda x:x[1], reverse = False)
    maxdis=dislis[-1][1]
    mindis=dislis[0][1]
    # print(maxdis,mindis)
    
    speeddic = {}
    for craft in samewayAircraftliscopy:
        speeddic[craft] = craft.current_v
    speedlis = sorted(speeddic.items(),key = lambda x:x[1], reverse = True)
    # print(speedlis)
    maxspeed=speedlis[0][1]
    minspeed=speedlis[-1][1]
    # print(maxspeed,minspeed)
    
    speedstructiondic= {} 
    for i in range(len(dislis)):
        speedstructiondic[dislis[i][0]]=speedlis[i][1]
    
    return speedstructiondic   #####返回的是同航路上各个航空器的速度值

#     return deltav        
        
#################################各类函数调用测试##########################
# from generate_track_basedon_critical_points import get_next_position,get_next_track9,get_next_track4,get_next_track2,get_predicted_track
# from multi_cb_conflicts_resolve import get_initial_trajectory
# flightplan=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], [113.851058959961, 23.0928325653076], 
#             [113.415802001953, 24.1916389465332], [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#             [110.77564239502, 24.6709175109863], [110.212219238281, 25.2047214508057], [109.608329772949, 25.7749996185303], 
#             [108.72721862793, 26.0091667175293], [108.39722442627, 26.0966663360596], [107.142776489258, 26.6330547332764], 
#             [106.780281066895, 26.7866668701172], [106.375274658203, 27.1991672515869], [106.062774658203, 27.5147228240967], 
#             [105.854721069336, 27.731388092041], [105.421417236328, 28.1706657409668], [105.042221069336, 28.4466667175293],
#             [104.753051757813, 28.6572227478027], [104.555809020996, 28.7995834350586], [104.304168701172, 29.9294452667236],
#             [104.391418457031, 30.8727493286133], [104.378723144531, 31.2490005493164], [104.366668701172, 31.4333324432373],
#             [104.316665649414, 32.4099998474121], [104.294998168945, 32.8600006103516], [104.270835876465, 33.3572235107422], 
#             [104.191390991211, 34.9758338928223], [104.151947021484, 35.7758331298828], [104.124725341797, 36.2794456481934], 
#             [104.112503051758, 36.5294456481934], [103.283889770508, 36.9369430541992], [102.439720153809, 37.3583335876465], 
#             [102.035278320313, 37.4375], [101.685554504395, 37.5047225952148], [101.316108703613, 37.6538887023926], 
#             [100.918891906738, 37.8291664123535], [100.011665344238, 38.2171669006348], [97.6258316040039, 39.2294425964355], 
#             [97.033332824707, 39.4669456481934], [96.6227798461914, 39.6308326721191], [95.1452789306641, 40.2000007629395], 
#             [94.8666687011719, 40.3058319091797], [93.8480529785156, 40.9150009155273], [91.6941680908203, 42.5183334350586],
#             [89.3930587768555, 43.5577774047852], [87.9815826416016, 44.171028137207], [88.2044448852539, 44.5552787780762], 
#             [88.317497253418, 44.7486114501953], [88.9844436645508, 45.8777770996094], [88.0850296020508, 47.7475814819336],
#             [87.466667175293, 49.091667175293]]
# callsign='CSN634'
# current=[106.7800, 26.7966668701172]

# aircraft1=Aircraft(callsign='CSN634',flightplan=flightplan.copy(),critical_track_points=flightplan.copy(),current_position=current,height=10130,heading=80)

# aa=aircraft1.flight_level_classify_ft(31090)
# print(aa)
# clouldlis=[[100,30,5],[110,25,1],[93,41,2.2],[109,42,1.2],[88,30,0.8],[89,35,0.6]]
# for i in aircraft1.critical_track_points[1:-1]:########删除被积雨云覆盖的航迹点
#     # print(i)
#     for j in clouldlis:
#         if (i[0]-j[0])**2+(i[1]-j[1])**2<j[2]**2:
#             aircraft1.critical_track_points.remove(i)
#             # print(i)
# critical_track_points=get_initial_trajectory(clouldlis,aircraft1.critical_track_points)
# aircraft1.add_critical_track_points(critical_track_points)

# next_nine_points=get_next_track9(aircraft1.current_position,aircraft1.critical_track_points,aircraft1.current_v,aircraft1.height)
# aircraft1.add_nine_critical_position(next_nine_points)
# next_four_points=get_next_track4(aircraft1.current_position,aircraft1.critical_track_points,aircraft1.current_v,aircraft1.height)
# aircraft1.add_four_critical_position(next_four_points)
# next_two_points=get_next_track2(aircraft1.current_position,aircraft1.critical_track_points,aircraft1.current_v,aircraft1.height)
# aircraft1.add_two_critical_position(next_two_points)
# next_eight_minutes_points=get_predicted_track(aircraft1.current_position,aircraft1.critical_track_points,aircraft1.current_v,aircraft1.height)
# aircraft1.add_eight_minute_predicted_position(next_eight_minutes_points)

# # print(aircraft1.critical_track_points)
# # print(aircraft1.eight_minute_predicted_position)
# print(aircraft1.nine_critical_position)

# intention=aircraft1.get_next_intention(aircraft1.two_critical_position,aircraft1.current_position)
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    

# x=[];y=[]
# for i in range(len(aircraft1.eight_minute_predicted_position)):
#     x.append(aircraft1.eight_minute_predicted_position[i]['point'+str(i)][0])
#     y.append(aircraft1.eight_minute_predicted_position[i]['point'+str(i)][1])
# ax.scatter(x,y,color='yellow',label='predicted')
# x=[];y=[]
# for i in range(len(aircraft1.critical_track_points)):
#     x.append(aircraft1.critical_track_points[i][0])
#     y.append(aircraft1.critical_track_points[i][1])
# ax.plot(x,y,color='red',alpha=0.5,label='critical_track_points')
# x=[];y=[]
# for i in range(len(aircraft1.nine_critical_position)):
#     x.append(aircraft1.nine_critical_position[i]['point'+str(i)][0])
#     y.append(aircraft1.nine_critical_position[i]['point'+str(i)][1])
# ax.plot(x,y,color='green',alpha=0.5,label='nine_critical_position')
# x=[];y=[]
# for i in aircraft1.flightplan:
#     x.append(i[0])
#     y.append(i[1])
# ax.scatter(x,y,color='blue',label='flight plan')  
# ax.scatter(aircraft1.current_position[0],aircraft1.current_position[1],color='red',label='current position')
# plt.legend()
# plt.show()


###############################场景1 冲突探测测试##########################
from generate_track_basedon_critical_points import get_next_position,get_next_track4,get_next_track2,get_next_track_point
from multi_cb_conflicts_resolve import get_initial_trajectory
import datetime
import random
import numpy as np
def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d
def generateplaninZGGG(planlis,initialtime,planname):
    flightplan={planname:[]}
    nowtime=datetime.datetime.strptime(initialtime,"%Y-%m-%d %H:%M:%S")
    
    for i in range(len(planlis)-1):
        flightplan[planname].append([planlis[i][0],planlis[i][1],'point'+str(i),nowtime])
        runningtime = (distance(planlis[i],planlis[i+1])/850)*3600
        nowtime += datetime.timedelta(seconds = round(runningtime,0))
    flightplan[planname].append([planlis[i+1][0],planlis[i+1][1],'point'+str(i+1),nowtime])    
    return flightplan
def generate_flight_level(current_point,next_point):
    heading=get_heading(current_point,next_point)
    if 0 < heading <= 180:
        levellis = [10700,10100,9500,8900]
        height=random.choice(levellis)
    else:
        levellis = [10400,9800,9200]
        height=random.choice(levellis)
    return height
def generate_craft(flightplan,hh):
    callsign1=list(flightplan.keys())[0]
    aircraft = Aircraft(callsign=callsign1,flightplan=flightplan[callsign1],critical_track_points=flightplan[callsign1],
                          current_position=[flightplan[callsign1][0][0],flightplan[callsign1][0][1]],
                          height=hh, current_v=1000,
                          # height=generate_flight_level(flightplan[callsign1][0],flightplan[callsign1][1]),
                          heading=get_heading(flightplan[callsign1][0],flightplan[callsign1][1]))
    return aircraft
def generate_craft2(flightplan,hh):
    callsign1=list(flightplan.keys())[0]
    aircraft = Aircraft(callsign=callsign1,flightplan=flightplan[callsign1],critical_track_points=flightplan[callsign1],
                          current_position=[flightplan[callsign1][0][0],flightplan[callsign1][0][1]],
                          height=hh, current_v=900,
                          # height=generate_flight_level(flightplan[callsign1][0],flightplan[callsign1][1]),
                          heading=get_heading(flightplan[callsign1][0],flightplan[callsign1][1]))
    return aircraft


def agent_control(aircraftlis):
    aircraftlis=aircraftlis.copy()
    conflictpairlis=[]
    dicttoavoid={}
    for i in range(len(aircraftlis)-1):
        # print(i)
        for j in range(i+1,len(aircraftlis)):
            # print(((aircraftlis[i].current_position[0]-aircraftlis[i].current_position[0])**2+(aircraftlis[i].current_position[1]-aircraftlis[i].current_position[1])**2)**(1/2))
            if aircraftlis[i].flightlevelm == aircraftlis[j].flightlevelm and ((aircraftlis[i].current_position[0]-aircraftlis[j].current_position[0])**2+(aircraftlis[i].current_position[1]-aircraftlis[j].current_position[1])**2)**(1/2)<=0.1636:
                conflictpairlis.append((aircraftlis[i],aircraftlis[j]))
                # print('fsdfwe')
    for conflictpair in  conflictpairlis:
        print(conflictpair[0].callsign,conflictpair[1].callsign)
        firstchoice=conflictpair[0].get_flight_level_available(aircraftlis,conflictpair[0])
        secondchoice=conflictpair[1].get_flight_level_available(aircraftlis,conflictpair[1])
        # if len(firstchoice)>len(secondchoice):
        conflictpair[0].get_flight_level_available(aircraftlis,conflictpair[0])
        dicttoavoid[conflictpair[0].callsign]=conflictpair[0].get_flight_level_available(aircraftlis,conflictpair[0])
        # if len(firstchoice)<len(secondchoice):
        #     conflictpair[1].get_flight_level_available(aircraftlis,conflictpair[1])
        #     dicttoavoid[conflictpair[1].callsign]=conflictpair[1].get_flight_level_available(aircraftlis,conflictpair[1])
        # if len(firstchoice)==len(secondchoice):
        #     a=random.choice([0,1])
        #     conflictpair[a].get_flight_level_available(aircraftlis,conflictpair[a])
        #     dicttoavoid[conflictpair[a].callsign]=conflictpair[a].get_flight_level_available(aircraftlis,conflictpair[a])
    
    return dicttoavoid
    # return {}#####{'callsign':{'height':,'speed':}}

# planlis1=[[0.8,0.1],[1,0],[2,0],[3,0],[4,0]]
# flightplan1=generateplaninZGGG(planlis1,'2023-07-23 09:00:00','CSN631')
# aircraft1 = generate_craft(flightplan1)
# planlis2=[[0.92,-0.1],[1,0],[2,-1]]
# flightplan2=generateplaninZGGG(planlis2,'2023-07-23 09:00:00','CSN632')
# aircraft2 = generate_craft(flightplan2)
# planlis3=[[0,0],[1,0],[2,0],[3,1]]
# flightplan3=generateplaninZGGG(planlis3,'2023-07-23 09:00:00','CSN633')
# aircraft3 = generate_craft(flightplan3)
# planlis4=[[0,-1],[1,0],[2,1],[3,1]]
# flightplan4=generateplaninZGGG(planlis4,'2023-07-23 09:00:00','CSN634')
# aircraft4 = generate_craft(flightplan4)
# planlis5=[[0,-1],[1,0],[2,1],[3,1]]
# flightplan5=generateplaninZGGG(planlis5,'2023-07-23 09:00:00','CSN635')
# aircraft5 = generate_craft(flightplan5)

# next_two_points=get_next_track2(current_point=aircraft1.current_position,
#                                 next_point=get_next_track_point(current_point=aircraft1.current_position,
#                                                                 tracklis=aircraft1.critical_track_points,
#                                                                 v=aircraft1.current_v,height=aircraft1.height),
#                                 tracklis=aircraft1.critical_track_points,
#                                 v=aircraft1.current_v,height=aircraft1.height)
# aircraft1.add_two_critical_position(next_two_points)

# next_two_points=get_next_track2(current_point=aircraft2.current_position,
#                                 next_point=get_next_track_point(current_point=aircraft2.current_position,
#                                                                 tracklis=aircraft2.critical_track_points,
#                                                                 v=aircraft2.current_v,height=aircraft2.height),
#                                 tracklis=aircraft2.critical_track_points,
#                                 v=aircraft2.current_v,height=aircraft2.height)
# aircraft2.add_two_critical_position(next_two_points)

# next_two_points=get_next_track2(current_point=aircraft3.current_position,
#                                 next_point=get_next_track_point(current_point=aircraft3.current_position,
#                                                                 tracklis=aircraft3.critical_track_points,
#                                                                 v=aircraft3.current_v,height=aircraft3.height),
#                                 tracklis=aircraft3.critical_track_points,
#                                 v=aircraft3.current_v,height=aircraft3.height)
# aircraft3.add_two_critical_position(next_two_points)

# next_two_points=get_next_track2(current_point=aircraft4.current_position,
#                                 next_point=get_next_track_point(current_point=aircraft4.current_position,
#                                                                 tracklis=aircraft4.critical_track_points,
#                                                                 v=aircraft4.current_v,height=aircraft4.height),
#                                 tracklis=aircraft4.critical_track_points,
#                                 v=aircraft4.current_v,height=aircraft4.height)
# aircraft4.add_two_critical_position(next_two_points)

# next_two_points=get_next_track2(current_point=aircraft5.current_position,
#                                 next_point=get_next_track_point(current_point=aircraft5.current_position,
#                                                                 tracklis=aircraft5.critical_track_points,
#                                                                 v=aircraft5.current_v,height=aircraft5.height),
#                                 tracklis=aircraft5.critical_track_points,
#                                 v=aircraft5.current_v,height=aircraft5.height)
# aircraft5.add_two_critical_position(next_two_points)
# # aircraft1.add_two_critical_position(next_two_points)
# aircraft1.flight_level_classify_m(aircraft1.height);aircraft1.get_next_intention(aircraft1.two_critical_position,aircraft1.current_position);aircraft1.get_heading()
# aircraft2.flight_level_classify_m(aircraft2.height);aircraft2.get_next_intention(aircraft2.two_critical_position,aircraft2.current_position);aircraft2.get_heading()
# aircraft3.flight_level_classify_m(aircraft3.height);aircraft3.get_next_intention(aircraft3.two_critical_position,aircraft3.current_position);aircraft3.get_heading()
# aircraft4.flight_level_classify_m(aircraft4.height);aircraft4.get_next_intention(aircraft4.two_critical_position,aircraft4.current_position);aircraft4.get_heading()
# aircraft5.flight_level_classify_m(aircraft5.height);aircraft5.get_next_intention(aircraft5.two_critical_position,aircraft5.current_position);aircraft5.get_heading()

def generate_craft_in_s2(planlis,time,callsign,hh):
    flightplan=generateplaninZGGG(planlis,time,callsign)
    aircraft=generate_craft(flightplan,hh=hh)
    next_two_points=get_next_track2(current_point=aircraft.current_position,
                                    next_point=get_next_track_point(current_point=aircraft.current_position,
                                                                    tracklis=aircraft.critical_track_points,
                                                                    v=aircraft.current_v,height=aircraft.height),
                                    tracklis=aircraft.critical_track_points,
                                    v=aircraft.current_v,height=aircraft.height)
    aircraft.add_two_critical_position(next_two_points)
    aircraft.flight_level_classify_m(aircraft.height);
    aircraft.get_next_intention(aircraft.two_critical_position,aircraft.current_position);
    aircraft.get_heading()
    return aircraft
def generate_craft_in_s22(planlis,time,callsign,hh):
    flightplan=generateplaninZGGG(planlis,time,callsign)
    aircraft=generate_craft2(flightplan,hh=hh)
    next_two_points=get_next_track2(current_point=aircraft.current_position,
                                    next_point=get_next_track_point(current_point=aircraft.current_position,
                                                                    tracklis=aircraft.critical_track_points,
                                                                    v=aircraft.current_v,height=aircraft.height),
                                    tracklis=aircraft.critical_track_points,
                                    v=aircraft.current_v,height=aircraft.height)
    aircraft.add_two_critical_position(next_two_points)
    aircraft.flight_level_classify_m(aircraft.height);
    aircraft.get_next_intention(aircraft.two_critical_position,aircraft.current_position);
    aircraft.get_heading()
    return aircraft
pl=[[0.8,0.1],[1,0],[2,0],[3,0],[4,0]]
t1='2023-07-23 09:00:00'
cs='CSN631'
aircraft1=generate_craft_in_s2(planlis=pl,time=t1,callsign=cs,hh=9800)
pl2=[[0.92,-0.1],[1,0],[2,-1]]
t2='2023-07-23 09:00:00'
cs2='CSN632'
aircraft2=generate_craft_in_s2(planlis=pl2,time=t2,callsign=cs2,hh=9800)
pl3=[[0,0],[1,0],[2,0],[3,1]]
t3='2023-07-23 09:00:00'
cs3='CSN633'
aircraft3=generate_craft_in_s2(planlis=pl3,time=t3,callsign=cs3,hh=9800)
pl4=[[0,-1],[1,0],[2,1],[3,1]]
t4='2023-07-23 09:00:00'
cs4='CSN634'
aircraft4=generate_craft_in_s2(planlis=pl4,time=t4,callsign=cs4,hh=9800)
aircraft4.current_v=900
pl5=[[0.2,-0.8],[1,0],[2,1],[3,1]]
t5='2023-07-23 09:00:00'
cs5='CSN635'
aircraft5=generate_craft_in_s2(planlis=pl5,time=t5,callsign=cs5,hh=9800)
pl6=[[0.8,0.1],[1,0],[2,0],[3,0],[4,0]]
t6='2023-07-23 09:00:00'
cs6='CSN637'
aircraft6=generate_craft_in_s22(planlis=pl6,time=t6,callsign=cs6,hh=9800)
pl7=[[0.4,-0.6],[1,0],[2,1],[3,1]]
t7='2023-07-23 09:00:00'
cs7='CSN638'
aircraft7=generate_craft_in_s2(planlis=pl7,time=t7,callsign=cs7,hh=9800)
aircraft7.current_v=800
# craftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]    
# conflictlis={}
# for craft in craftlis:
#     craftlis=craftlis.copy()
#     conflictsDic=craft.judge_conflicts(aircraftSet=craftlis,thisAircraft=craft)
#     conflictlis[craft.callsign]=conflictsDic
    
# aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]
# conflictsDic1=aircraft1.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft1)
# # aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]
# conflictsDic2=aircraft2.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft2)
# # aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]
# conflictsDic3=aircraft3.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft3)
# # aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]
# conflictsDic4=aircraft4.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft4)
# # aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]
# conflictsDic5=aircraft5.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft5)
def get_conflict_dic(craftlis):
    conflictlis={}
    for craft in craftlis:
        craftlis=craftlis.copy()
        conflictsDic=craft.judge_conflicts(aircraftSet=craftlis,thisAircraft=craft)
        conflictlis[craft]=conflictsDic
    return conflictlis
craftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7]    
conflictlisDic=get_conflict_dic(craftlis)
##########################场景2 获得可用高度层##########################

# aircraft1.add_two_critical_position(next_two_points)
def mid_process(aircraft):
    aircraft.flight_level_classify_m(aircraft.height)
    aircraft.get_next_intention(aircraft.two_critical_position,aircraft.current_position)
    aircraft.get_heading()
for craft in craftlis:
    mid_process(craft)
# aircraft1.flight_level_classify_m(aircraft1.height);aircraft1.get_next_intention(aircraft1.two_critical_position,aircraft1.current_position);aircraft1.get_heading()
# aircraft2.flight_level_classify_m(aircraft2.height);aircraft2.get_next_intention(aircraft2.two_critical_position,aircraft2.current_position);aircraft2.get_heading()
# aircraft3.flight_level_classify_m(aircraft3.height);aircraft3.get_next_intention(aircraft3.two_critical_position,aircraft3.current_position);aircraft3.get_heading()
# aircraft4.flight_level_classify_m(aircraft4.height);aircraft4.get_next_intention(aircraft4.two_critical_position,aircraft4.current_position);aircraft4.get_heading()
# aircraft5.flight_level_classify_m(aircraft5.height);aircraft5.get_next_intention(aircraft5.two_critical_position,aircraft5.current_position);aircraft5.get_heading()
# aircraft6.flight_level_classify_m(aircraft6.height);aircraft6.get_next_intention(aircraft6.two_critical_position,aircraft6.current_position);aircraft6.get_heading()
# aircraft7.flight_level_classify_m(aircraft7.height);aircraft7.get_next_intention(aircraft7.two_critical_position,aircraft7.current_position);aircraft7.get_heading()
aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7]
# alt1=aircraft1.get_flight_level_available(aircraftlis,aircraft1)
# altininstruction=alt1[0]

def get_altD9c(craftlis,conflictlisDic):
    altDicforconflict={}
    for craft in craftlis:
        # print(craft.callsign)
        if conflictlisDic[craft]['same_point'] != [] or conflictlisDic[craft]['same_way'] != []:
            altDicforconflict[craft] = craft.get_flight_level_available(craftlis,craft)
    return altDicforconflict
altitudeadj=get_altD9c(craftlis,conflictlisDic)
speedadjDicsameway=speed_adjust_sameway(aircraft4,conflictlisDic[aircraft4]['same_way'])
#####################场景3  速度调节实验#################
###if alt == []:
#################附近没有可用高度层时，转到这里
A1_intention=aircraft1.intention
position1=aircraft1.current_position
D1=((A1_intention[0]-position1[0])**2+(A1_intention[1]-position1[1])**2)**(1/2)
A2_intention=aircraft2.intention
position2=aircraft2.current_position
D2=((A2_intention[0]-position2[0])**2+(A2_intention[1]-position2[1])**2)**(1/2)
v1=aircraft1.current_v/(110*3600)
v2=aircraft2.current_v/(110*3600)
p1=[A1_intention[0]-position1[0],A1_intention[1]-position1[1]]
p2=[A2_intention[0]-position2[0],A2_intention[1]-position2[1]]
cosxita=(p1[0]*p2[0]+p1[1]*p2[1])/(((p1[0]**2+p1[1]**2)**(1/2))*((p2[0]**2+p2[1]**2)**(1/2)))
xita=np.arccos(cosxita)*180/np.pi
lamda=(D1*v1 - D1*v2*cosxita - D2*v1*cosxita + D2*v2)/(v1**2 - 2*v1*v2*cosxita + v2**2)
d2=(D1 - v1*lamda)**2 - (2*D1 - 2*v1*lamda)*(D2 - v2*lamda)*cosxita + (D2 - v2*lamda)**2
d=d2**(1/2)

# print('调整前最小间隔：',d*110)
# print(xita)
# deltav=18.52/(110*3600)
# while d <=0.1:
#     if D1 >= D2:
#         v1=v1-deltav
#         v2=v2+deltav
#     else:
#         v1=v1+deltav
#         v2=v2-deltav
#     lamda=(D1*v1 - D1*v2*cosxita - D2*v1*cosxita + D2*v2)/(v1**2 - 2*v1*v2*cosxita + v2**2)
#     d2=(D1 - v1*lamda)**2 - (2*D1 - 2*v1*lamda)*(D2 - v2*lamda)*cosxita + (D2 - v2*lamda)**2
#     d=d2**(1/2)
#     deltav+=18.52/(110*3600)
#     print('调整后最小间隔：',d*110,'km')
#     print('调整后v1：',v1*(110*3600),'km/h')
#     print('调整后v2：',v2*(110*3600),'km/h')
################调用函数测试
deltav=speed_adjust_intersection(aircraft1,aircraft2)

#####还差一个跟随的

# #######################状态转移测试############
# from generate_track_basedon_critical_points import get_next_track_point,get_instruction
# from multi_cb_conflicts_resolve import get_initial_trajectory
# flightplan=[[114.133331298828, 22.5433330535889], [113.851058959961, 23.0928325653076], 
#             [113.415802001953, 24.1916389465332], [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#             [110.77564239502, 24.6709175109863], [110.212219238281, 25.2047214508057], [109.608329772949, 25.7749996185303], 
#             [108.72721862793, 26.0091667175293], [108.39722442627, 26.0966663360596], [107.142776489258, 26.6330547332764], 
#             [106.780281066895, 26.7866668701172], [106.375274658203, 27.1991672515869], [106.062774658203, 27.5147228240967], 
#             [105.854721069336, 27.731388092041], [105.421417236328, 28.1706657409668], [105.042221069336, 28.4466667175293],
#             [104.753051757813, 28.6572227478027], [104.555809020996, 28.7995834350586], [104.304168701172, 29.9294452667236],
#             [104.391418457031, 30.8727493286133], [104.378723144531, 31.2490005493164], [104.366668701172, 31.4333324432373],
#             [104.316665649414, 32.4099998474121], [104.294998168945, 32.8600006103516], [104.270835876465, 33.3572235107422], 
#             [104.191390991211, 34.9758338928223], [104.151947021484, 35.7758331298828], [104.124725341797, 36.2794456481934], 
#             [104.112503051758, 36.5294456481934], [103.283889770508, 36.9369430541992], [102.439720153809, 37.3583335876465], 
#             [102.035278320313, 37.4375], [101.685554504395, 37.5047225952148], [101.316108703613, 37.6538887023926], 
#             [100.918891906738, 37.8291664123535], [100.011665344238, 38.2171669006348], [97.6258316040039, 39.2294425964355], 
#             [97.033332824707, 39.4669456481934], [96.6227798461914, 39.6308326721191], [95.1452789306641, 40.2000007629395], 
#             [94.8666687011719, 40.3058319091797], [93.8480529785156, 40.9150009155273], [91.6941680908203, 42.5183334350586],
#             [89.3930587768555, 43.5577774047852], [87.9815826416016, 44.171028137207], [88.2044448852539, 44.5552787780762], 
#             [88.317497253418, 44.7486114501953], [88.9844436645508, 45.8777770996094], [88.0850296020508, 47.7475814819336],
#             [87.466667175293, 49.091667175293]]
# callsign='CSN634'
# current=[114.133331298828, 22.5433330535889]
# craft_CSN634=Aircraft(callsign='CSN634',flightplan=flightplan.copy(),critical_track_points=flightplan.copy(),current_position=current,height=12400,heading=80)
# # for i in range(len(flightplan)):
# #     if ()**2+()**2<=
# dellis=[]
# for k in range(len(flightplan)-1):
#     if (flightplan[k+1][0]-flightplan[k][0])**2+(flightplan[k+1][1]-flightplan[k][1])**2<=(9/110)**2:
#         # print('True')
#         dellis.append(k)
# aa=flightplan
# #删除列表中的元素,其所在的位置为[1,3,7]
# del_index=dellis
# tmp=[i for num,i in enumerate(aa) if num not in del_index]
# flightplan=tmp    
    

# i=0
# next_point = get_next_track_point(current_point=craft_CSN634.current_position,tracklis=craft_CSN634.critical_track_points,v=craft_CSN634.current_v,height=craft_CSN634.height)
# for i in range(3600*12):
#     next_point = get_next_track_point(current_point=craft_CSN634.current_position,tracklis=craft_CSN634.critical_track_points,v=craft_CSN634.current_v,height=craft_CSN634.height)
#     # print(next_point )
#     if next_point == 'arrive':
#         break
#     elif next_point=='abnormal':
#         next_point=craft_CSN634.critical_track_points[-1]
#         instruction = get_instruction(current_point=craft_CSN634.current_position,next_point=next_point)
#     else:
#         instruction = get_instruction(current_point=craft_CSN634.current_position,next_point=next_point['point0'])
#     # print(instruction)
#     craft_CSN634.doing_current_instruction(instruction,0)
#     i=i+1
#     print(i)
# instruction={'speed':1050,'flightlevel':10400,'heading':60,'timeinterval':1}
# for i in range(50):
#     craft_CSN634.doing_current_instruction(instruction,0)
# instruction={'speed':1050,'flightlevel':9500,'heading':90,'timeinterval':1}
# for i in range(20):
#     craft_CSN634.doing_current_instruction(instruction,0)
# instruction={'speed':1050,'flightlevel':9500,'heading':130,'timeinterval':1}
# for i in range(20):
#     craft_CSN634.doing_current_instruction(instruction,0)
# instruction={'speed':1050,'flightlevel':9500,'heading':200,'timeinterval':1}
# for i in range(20):
#     craft_CSN634.doing_current_instruction(instruction,0)
# instruction={'speed':1050,'flightlevel':9800,'heading':270,'timeinterval':1}

# ##############三维图像###############
# xx=[];yy=[];zz=[]

# for i in craft_CSN634.tracklis:
#     xx.append(i[0])
#     yy.append(i[1])
#     zz.append(i[2])
# import matplotlib.pyplot as plt
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# ax.scatter(xx,yy,zz)

# x=[];y=[];z=[]
# for i in flightplan:
#     x.append(i[0])
#     y.append(i[1])
#     z.append(9500)
# ax.scatter(x,y,z,color='green')

# ###############二维图像###############
# import matplotlib.pyplot as plt
# x=[];y=[]
# for i in craft_CSN634.tracklis:
#     x.append(i[0])
#     y.append(i[1])
# plt.scatter(x,y,color='red',s=30)

# xx=[];yy=[];zz=[]
# for i in craft_CSN634.critical_track_points:
#     xx.append(i[0])
#     yy.append(i[1])
# plt.scatter(xx,yy,color='blue',s=30)
'''
整体逻辑:
    完成水平航迹规划后生成关键航迹点
    基于关键航迹点进行高度层分配和速度调配
    生成四维航迹[lon,lat,alt,speed,heading,timestamp]
    爬升率选择1500ft/min(一般爬升)或2000ft/min(快速爬升),即457m/min,600m/min,爬升下降到下一个高度层
'''





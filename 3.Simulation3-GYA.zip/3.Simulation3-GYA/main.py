leftpoint1=[111.9,23.615]
leftpoint2=[111.8175,23.2]
leftpoint3=[111.8,22.995]
leftpoint4=[111.9,22.556]
middlepointGYA=[112.4852,23.07]
rightpoint1=[113.1916,23.02]
rightpoint2=[112.928,22.674]
rightpoint3=[112.816,22.585]

import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from mpl_toolkits.basemap import Basemap
import numpy as np
import pandas as pd
from generate_track_basedon_critical_points import get_next_position,get_next_track9,get_next_track4,get_next_track2,get_predicted_track
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=16.0##########小四
plt.rcParams["text.color"]='black'#############图例和标题文本字体颜色（）
plt.rcParams["mathtext.fontset"]='stix'
ax=plt.gca()
fig = plt.figure(1) #定义figure，（1）中的1是什么
ax.scatter(leftpoint1[0],leftpoint1[1],marker='^',color='royalblue',s=80)
ax.scatter(leftpoint2[0],leftpoint2[1],marker='^',color='royalblue',s=80)
ax.scatter(leftpoint3[0],leftpoint3[1],marker='^',color='royalblue',s=80)
ax.scatter(leftpoint4[0],leftpoint4[1],marker='^',color='royalblue',s=80)
ax.scatter(middlepointGYA[0],middlepointGYA[1],marker='^',color='blue',s=120)
ax.text(middlepointGYA[0]+0.025,middlepointGYA[1]+0.03,'GYA',c='blue',fontsize=18,fontdict={'family':'SimHei','size':23})
ax.scatter(rightpoint1[0],rightpoint1[1],marker='^',color='royalblue',s=80)
ax.scatter(rightpoint2[0],rightpoint2[1],marker='^',color='royalblue',s=80)
ax.scatter(rightpoint3[0],rightpoint3[1],marker='^',color='royalblue',s=80)
ax.plot([leftpoint1[0],middlepointGYA[0]],[leftpoint1[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
ax.plot([leftpoint2[0],middlepointGYA[0]],[leftpoint2[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
ax.plot([leftpoint3[0],middlepointGYA[0]],[leftpoint3[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
ax.plot([leftpoint4[0],middlepointGYA[0]],[leftpoint4[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
ax.plot([rightpoint1[0],middlepointGYA[0]],[rightpoint1[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
ax.plot([rightpoint2[0],middlepointGYA[0]],[rightpoint2[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
ax.plot([rightpoint3[0],middlepointGYA[0]],[rightpoint3[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
plt.xlim(111.78,113.35)
plt.ylim(22.52,23.63)
from matplotlib import pyplot as plt
from matplotlib.path import Path
# '通过Path类自定义marker'
#定义旋转矩阵
def rot(verts, az):
    #顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts
iconMat = 100*np.array([[0, 9],[1,8],
			[1, 2],
			[7, -3],
			[7, -6],
			[1, -3],
            [1,-9],
            [3,-9.5],
            [3,-10.8],
            [0.3,-10],
            [0,-12],
            [-0.3,-10],[-3,-10.8],[-3,-9.5],[-1,-9],[-1,-3],[-7,-6],[-7,-3],[-1,2],[-1,8],[0,9]])
class CustomMarker1(Path):
    def __init__(self, icon, az):
         if icon == "icon": 
             verts = iconMat  
         vertices = rot(verts, az)  
         super().__init__(vertices)
def plot_iconandinfo_east_4(ax,lon,lat,alt,heading,speed,callsign):
    ax.scatter(lon,lat, marker=CustomMarker1("icon", heading), c="green", s=500)  
    if lon<= 112.4852:    
        deltalon=0.124;deltalat=-0.06
    else:
        deltalon=-0.12;deltalat=0.06
    ax.text(lon+deltalon,lat+deltalat,'Callsign: '+callsign+'\n'+'QNE: '+str(alt)+' (m)\n'+'GS: '+str(speed)+' (km/h)',bbox=dict(boxstyle='round,pad=0.5', fc='yellow', ec='k',lw=1 ,alpha=0.1))
    plt.plot([lon,lon+deltalon],[lat,lat+deltalat],linewidth=1,color='black',alpha=0.3)
def plot_iconandinfo_east_3(ax,lon,lat,alt,heading,speed,callsign):
    ax.scatter(lon,lat, marker=CustomMarker1("icon", heading), c="brown", s=500)  
    if lon<= 112.1:    
        deltalon=-0.124;deltalat=-0.2
    elif lon<= 112.4852:
        deltalon=-0.424;deltalat=-0.16
    else:
        deltalon=-0.42;deltalat=-0.11
    ax.text(lon+deltalon,lat+deltalat,'Callsign: '+callsign+'\n'+'QNE: '+str(alt)+' (m)\n'+'GS: '+str(speed)+' (km/h)',bbox=dict(boxstyle='round,pad=0.5', fc='yellow', ec='k',lw=1 ,alpha=0.1))
    plt.plot([lon,lon+deltalon],[lat,lat+deltalat],linewidth=1,color='black',alpha=0.3)
def plot_iconandinfo_east_2(ax,lon,lat,alt,heading,speed,callsign):
    ax.scatter(lon,lat, marker=CustomMarker1("icon", heading), c="purple", s=500)  
    if lon<= 112.1:    
        deltalon=-0.124;deltalat=0.039
    elif lon<= 112.4852:
        deltalon=-0.324;deltalat=0.039
    else:
        deltalon=-0.12;deltalat=-0.23
    ax.text(lon+deltalon,lat+deltalat,'Callsign: '+callsign+'\n'+'QNE: '+str(alt)+' (m)\n'+'GS: '+str(speed)+' (km/h)',bbox=dict(boxstyle='round,pad=0.5', fc='yellow', ec='k',lw=1 ,alpha=0.1))
    plt.plot([lon,lon+deltalon],[lat,lat+deltalat],linewidth=1,color='black',alpha=0.3)
def plot_iconandinfo_east_1(ax,lon,lat,alt,heading,speed,callsign):
    ax.scatter(lon,lat, marker=CustomMarker1("icon", heading), c="gray", s=500)  
    if lon<= 112.1:    
        deltalon=0.124;deltalat=-0.1
    elif lon<= 112.4852:
        deltalon=-0.324;deltalat=0.12
    else:
        deltalon=-0.224;deltalat=0.35
    ax.text(lon+deltalon,lat+deltalat,'Callsign: '+callsign+'\n'+'QNE: '+str(alt)+' (m)\n'+'GS: '+str(speed)+' (km/h)',bbox=dict(boxstyle='round,pad=0.5', fc='yellow', ec='k',lw=1 ,alpha=0.1))
    plt.plot([lon,lon+deltalon],[lat,lat+deltalat],linewidth=1,color='black',alpha=0.3)        
    
# plot_iconandinfo_east_4(ax,lon=111.926,lat=22.585,alt=9800,heading=60,speed=900,callsign='CSN634')    
# plot_iconandinfo_east_4(ax,lon=112.5852,lat=23.07,alt=9800,heading=60,speed=900,callsign='CSN634')        
    
# plot_iconandinfo_east_3(ax,lon=111.926,lat=23.005,alt=9800,heading=80,speed=900,callsign='CSN635')    
# plot_iconandinfo_east_3(ax,lon=113.1852,lat=23.00,alt=9800,heading=60,speed=900,callsign='CSN635')    

# plot_iconandinfo_east_2(ax,lon=111.926,lat=23.205,alt=9800,heading=80,speed=900,callsign='CSN636')    
# plot_iconandinfo_east_2(ax,lon=113.1052,lat=23.0,alt=9800,heading=60,speed=900,callsign='CSN636')  

# plot_iconandinfo_east_1(ax,lon=111.886,lat=23.605,alt=9800,heading=80,speed=900,callsign='CSN637')    
# plot_iconandinfo_east_1(ax,lon=113.1052,lat=23.0,alt=9800,heading=60,speed=900,callsign='CSN637')  
ax.set_xlabel('Longitude($^o$)')
ax.set_ylabel('Latitude($^o$)')
plt.show()

# ax.scatter(111.926,22.585, marker=CustomMarker1("icon", 60), c="green", s=500)     
# ax.text(112.05,22.525,'Callsign:CSN634\nQNE: 9800 (m)\nGS: 900 (km/h)',bbox=dict(boxstyle='round,pad=0.5', fc='yellow', ec='k',lw=1 ,alpha=0.1))
# plt.plot([111.926,112.05],[22.585,22.525],linewidth=1,color='black',alpha=0.3)
# # ax.scatter(x0[500], y0[500], marker=CustomMarker1("icon", H0[500]), c="red", s=250)
from class_aircraft import Aircraft
flightplan1=[[111.9,23.615],[112.4852,23.07],[113.1916,23.02]]
flightplan2=[[111.8175,23.2],[112.4852,23.07],[112.928,22.674]]
flightplan3=[[111.8,22.995],[112.4852,23.07],[112.816,22.585]]
flightplan4=[[111.9,22.556],[112.4852,23.07],[113.1916,23.02]]


callsign1='CCA1307'
current1=[111.9,23.615]
callsign2='CSN217'
current2=[111.8175,23.2]
callsign3='CXA1421'
current3=[111.8,22.995]
callsign4='MU5173'
current4=[111.9,22.556]

from generate_track_basedon_critical_points import get_next_track_point
aircraft1=Aircraft(callsign=callsign1,flightplan=flightplan1,critical_track_points=flightplan1,current_position=current1,height=10113,heading=0,current_v=900)
aircraft2=Aircraft(callsign=callsign2,flightplan=flightplan2,critical_track_points=flightplan2,current_position=current2,height=10113,heading=0,current_v=900)
aircraft3=Aircraft(callsign=callsign3,flightplan=flightplan3,critical_track_points=flightplan3,current_position=current3,height=10113,heading=0,current_v=900)
aircraft4=Aircraft(callsign=callsign4,flightplan=flightplan4,critical_track_points=flightplan4,current_position=current4,height=10113,heading=0,current_v=900)

# next_point=get_next_track_point(current_point,tracklis,900,9800)
# next_c_point=get_next_track2(current_point,next_point['point0'],tracklis,v=800,height=9800)



next_point1=get_next_track_point(aircraft1.current_position,aircraft1.critical_track_points,aircraft1.current_v,aircraft1.height)
aircraft1.intention=next_point1['point0']
aircraft1.flight_level_classify_m(aircraft1.height);aircraft1.get_heading()

next_point2=get_next_track_point(aircraft2.current_position,aircraft2.critical_track_points,aircraft2.current_v,aircraft2.height)
aircraft2.intention=next_point2['point0']
aircraft2.flight_level_classify_m(aircraft2.height);aircraft2.get_heading()

next_point3=get_next_track_point(aircraft3.current_position,aircraft3.critical_track_points,aircraft3.current_v,aircraft3.height)
aircraft3.intention=next_point3['point0']
aircraft3.flight_level_classify_m(aircraft3.height);aircraft3.get_heading()

next_point4=get_next_track_point(aircraft4.current_position,aircraft4.critical_track_points,aircraft4.current_v,aircraft4.height)
aircraft4.intention=next_point4['point0']
aircraft4.flight_level_classify_m(aircraft4.height);aircraft4.get_heading()

aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4]
conflictsDic1=aircraft1.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft1)
conflictsDic2=aircraft2.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft2)
conflictsDic3=aircraft3.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft3)


from class_aircraft import speed_adjust_intersection
# conflictDiclis={}

    
# for ii in range(len(aircraftlis)):
#     # # print(aircraftlis[ii].callsign)
#     # for jj in range(ii+1,len(aircraftlis)):
#         cd=aircraftlis[ii].judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraftlis[ii])
#         conflictDiclis.append(cd)    
# disdict = {}  
# for craft in aircraftlis:
#     # print(craft.current_position)
#     # print(craft.intention)
#     disdict[craft.callsign] = (craft.current_position[1] - craft.intention[1])**2 + (craft.current_position[0] - craft.intention[0])**2
# dislis = sorted(disdict.items(),key = lambda x:x[1], reverse = False)    
# speeddic={}
# for craft in aircraftlis:
#     speeddic[craft.callsign]=0
# for ii in range(len(aircraftlis)):
#     for jj in conflictDiclis[ii][aircraftlis[ii]]['same_point']:
#         speeddic[aircraftlis[ii].callsign]=speed_adjust_intersection(aircraft1=aircraftlis[ii],aircraft2=aircraftlis[jj])+speeddic[aircraftlis[ii].callsign]
    

decisionDic={}
decisionOrder={}

tc=speed_adjust_intersection(aircraft1=aircraft2,aircraft2=aircraft4)

disdict = {}  
for craft in aircraftlis:
    # print(craft.current_position)
    # print(craft.intention)
    disdict[craft.callsign] = (craft.current_position[1] - craft.intention[1])**2 + (craft.current_position[0] - craft.intention[0])**2
dislis = sorted(disdict.items(),key = lambda x:x[1], reverse = False)
speeddic={}
for craft in aircraftlis:
    speeddic[craft.callsign]=0
for ii in range(len(aircraftlis)):
    # print(aircraftlis[ii].callsign)
    for jj in range(ii+1,len(aircraftlis)):
        # print(aircraftlis[jj].callsign)
        speeddic[aircraftlis[ii].callsign]=speed_adjust_intersection(aircraft1=aircraftlis[ii],aircraft2=aircraftlis[jj])+speeddic[aircraftlis[ii].callsign]
        # speeddic[aircraftlis[jj].callsign]=speed_adjust_intersection(aircraft1=aircraftlis[ii],aircraft2=aircraftlis[jj])+speeddic[craft.callsign]
        # print(speeddic)


def get_speeddic(aircraftlis):
    disdict = {}  
    for craft in aircraftlis:
        # print(craft.current_position)
        # print(craft.intention)
        disdict[craft.callsign] = (craft.current_position[1] - craft.intention[1])**2 + (craft.current_position[0] - craft.intention[0])**2
    dislis = sorted(disdict.items(),key = lambda x:x[1], reverse = False)
    
    speeddic={}
    for craft in aircraftlis:
        speeddic[craft.callsign]=0
    for ii in range(len(aircraftlis)):
        # print(aircraftlis[ii].callsign)
        for jj in range(ii+1,len(aircraftlis)):
            conflictsDic=aircraft1.judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraftlis[ii])
            # print(aircraftlis[jj].callsign)
            speeddic[aircraftlis[ii].callsign]=speed_adjust_intersection(aircraft1=aircraftlis[ii],aircraft2=aircraftlis[jj])+speeddic[aircraftlis[ii].callsign]
            # speeddic[aircraftlis[jj].callsign]=speed_adjust_intersection(aircraft1=aircraftlis[ii],aircraft2=aircraftlis[jj])+speeddic[craft.callsign]
            # print(speeddic)
    for craft in aircraftlis:
        speeddic[craft.callsign]=speeddic[craft.callsign]
    return speeddic
aaa=get_speeddic(aircraftlis)
'''下一步，按照dislis的顺序对每个航空器进行速度决策
调速求和

最终的deltav就是所有航空器对加起来

'''

# next_2_point=get_next_track2(aircraft1.current_position,next_point,aircraft1.critical_track_points,


# aircraft1.flight_level_classify_m(aircraft1.height);aircraft1.get_next_intention(aircraft1.two_critical_position,aircraft1.current_position);aircraft1.get_heading()
# aircraft2.flight_level_classify_m(aircraft2.height);aircraft2.get_next_intention(aircraft2.two_critical_position,aircraft2.current_position);aircraft2.get_heading()
# aircraft3.flight_level_classify_m(aircraft3.height);aircraft3.get_next_intention(aircraft3.two_critical_position,aircraft3.current_position);aircraft3.get_heading()
# aircraft4.flight_level_classify_m(aircraft4.height);aircraft4.get_next_intention(aircraft4.two_critical_position,aircraft4.current_position);aircraft4.get_heading()
# def plot_list(lis):
#     x=[];y=[]
#     for i in lis:
#         x.append(i[0])
#         y.append(i[1])
#     ax.plot(x,y)
# plot_list(flightplan1);plot_list(flightplan2);plot_list(flightplan3);plot_list(flightplan4)

# Alis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7,aircraft8,aircraft9,aircraft10,aircraft11,aircraft12,aircraft13,aircraft14,aircraft15,aircraft16,aircraft20,aircraft21,
#        aircraft22,aircraft23,aircraft24,aircraft25,aircraft27,aircraft28,aircraft29,aircraft31,aircraft4c,aircraft5c,aircraft6c,aircraft7c]
from generate_track_basedon_critical_points import get_next_track_point,get_instruction,get_next_track4,get_heading
from multi_cb_conflicts_resolve import get_c_lis
from class_aircraft import Aircraft,speed_adjust_intersection
from class_aircraft import mid_process
# from class_aircraft import agent_control_speed
import datetime
def getFutureTime(timestamp,it,format='%Y-%m-%d %H:%M:%S'):
    '''
    以给定时间戳为基准，前进 hours 个小时得到对应的时间戳
    '''
    now_time=datetime.datetime.strptime(timestamp,'%Y-%m-%d %H:%M:%S')
    for i in range(it):
        now_time+=datetime.timedelta(seconds=4)
    next_timestamp=now_time.strftime('%Y-%m-%d %H:%M:%S')
    # print ('next_timestamp: ',next_timestamp)
    return next_timestamp
Alis=[aircraft1,aircraft2,aircraft3,aircraft4]
finalAlis=[]
ccc=[]
#       ]
for craft in Alis:
    craft.get_change_instruction(instruction=0)
# for t in range(1,388):   

timestamp='2023-05-23 09:00:00'
stamplis=[]

ccc=[]
for i in range(150):
    tt=getFutureTime(timestamp, it=i, format='%Y-%m-%d %H:%M:%S')
    stamplis.append(tt)
for t in range(len(stamplis)):
# for t in range(230):
    print(t)
    cloudlis=[]
    # cloudlis=bigcloudlis[t]
    ##################每个时间戳加入航空器##########
    # conflictlisDic=get_conflict_dic(Alis)
    # print(conflictlisDic)
    # conflictpairdic=agent_control_speed(Alis)
    # ccc.append(conflictpairdic)
    for craft in Alis:
        mid_process(craft)
    speeddict=get_speeddic(Alis)
    ccc.append(speeddict)
    # altitudeadj=get_altD9c(craftlis=Alis,conflictlisDic=conflictlisDic)
    # ddd.append(altitudeadj)
    # print(altitudeadj)
    # Alis=[aircraft1,aircraft15]
    # Alis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5,aircraft6,aircraft7,aircraft8,aircraft9,aircraft10,aircraft11,aircraft12,aircraft13,aircraft14,aircraft15,aircraft16,aircraft20,aircraft21,
    #       aircraft22,aircraft23,aircraft24,aircraft25,aircraft27,aircraft28,aircraft29,aircraft31,aircraft4c,aircraft5c,aircraft6c,aircraft7c]
    ###################计算未来几个关键航迹点(比如：4个)################
    for craft in Alis:
        critical_tralis=craft.flightplan
        i_t= get_c_lis(cloudlis,critical_tralis)  
        if i_t == 'diversion':
            # print('diversion'+craft.callsign)
            Alis.remove(craft)
            # finalAlis.append(craft)
            continue
        else:
            craft.add_critical_track_points(i_t)
        next_point = get_next_track_point(current_point=craft.current_position,tracklis=craft.critical_track_points,v=craft.current_v,height=craft.height)
        if next_point == 'arrive':
            Alis.remove(craft)
            finalAlis.append(craft)
            continue
        
        elif next_point=='abnormal':
            next_point=[craft.critical_track_points[-1][0],craft.critical_track_points[-1][1]]
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point,aircraft=craft,speeddict=speeddict)
            # craft.speed=
        else:
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point['point0'],aircraft=craft,speeddict=speeddict)
        if craft.callsign=='CCA1307':
            if 112.2852 <=craft.current_position[0]<= 112.4852:
                instruction['speed']=862.96
        if craft.current_position[0] >= 112.4052:
            instruction['speed']=craft.current_v
            
        craft.get_change_instruction(instruction)

        craft.doing_current_instruction(craft.instruction,stamplis[t])


def plot_track(aircraft):
    xx=[];yy=[]
    for i in aircraft.tracklis:
        xx.append(i[0])
        yy.append(i[1])
    ax.plot(xx,yy)
# plot_track(aircraft1)    
# plot_track(aircraft2) 
# plot_track(aircraft3) 
# plot_track(aircraft4) 
        
        
def animation_in_s(numberofpci,interval):        
    for i in range(1,numberofpci):
        print(i)    
        import matplotlib.pyplot as plt
        from matplotlib.patches import Polygon
        from mpl_toolkits.basemap import Basemap
        import numpy as np
        import pandas as pd
        from generate_track_basedon_critical_points import get_next_position,get_next_track9,get_next_track4,get_next_track2,get_predicted_track
        plt.rcParams["font.family"]='Times New Roman'######全局字体
        plt.rcParams["font.size"]=16.0##########小四
        plt.rcParams["text.color"]='black'#############图例和标题文本字体颜色（）
        plt.rcParams["mathtext.fontset"]='stix'
        ax=plt.gca()
        fig = plt.figure(1) #定义figure，（1）中的1是什么
        ax.scatter(leftpoint1[0],leftpoint1[1],marker='^',color='royalblue',s=80)
        ax.scatter(leftpoint2[0],leftpoint2[1],marker='^',color='royalblue',s=80)
        ax.scatter(leftpoint3[0],leftpoint3[1],marker='^',color='royalblue',s=80)
        ax.scatter(leftpoint4[0],leftpoint4[1],marker='^',color='royalblue',s=80)
        ax.scatter(middlepointGYA[0],middlepointGYA[1],marker='^',color='blue',s=120)
        ax.text(middlepointGYA[0]+0.025,middlepointGYA[1]+0.03,'GYA',c='blue',fontsize=18,fontdict={'family':'Times New Roman','size':23})
        ax.scatter(rightpoint1[0],rightpoint1[1],marker='^',color='royalblue',s=80)
        ax.scatter(rightpoint2[0],rightpoint2[1],marker='^',color='royalblue',s=80)
        ax.scatter(rightpoint3[0],rightpoint3[1],marker='^',color='royalblue',s=80)
        ax.plot([leftpoint1[0],middlepointGYA[0]],[leftpoint1[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        ax.plot([leftpoint2[0],middlepointGYA[0]],[leftpoint2[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        ax.plot([leftpoint3[0],middlepointGYA[0]],[leftpoint3[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        ax.plot([leftpoint4[0],middlepointGYA[0]],[leftpoint4[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        ax.plot([rightpoint1[0],middlepointGYA[0]],[rightpoint1[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        ax.plot([rightpoint2[0],middlepointGYA[0]],[rightpoint2[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        ax.plot([rightpoint3[0],middlepointGYA[0]],[rightpoint3[1],middlepointGYA[1]],color='royalblue',linewidth=5,alpha=0.5)
        plt.xlim(111.78,113.3)
        plt.ylim(22.52,23.63)        
        ax.set_xlabel('Longitude($^o$)')
        ax.set_ylabel('Latitude($^o$)')        
                 
        # plot_iconandinfo_east_2(ax,lon=aircraft2.tracklis[0][0],lat=aircraft2.tracklis[0][1],alt=9800,heading=80,speed=900,callsign='CSN217')           
        # plot_iconandinfo_east_3(ax,lon=aircraft3.tracklis[0][0],lat=aircraft3.tracklis[0][1],alt=9800,heading=80,speed=900,callsign='CXA1421')   
        # plot_iconandinfo_east_4(ax,lon=aircraft4.tracklis[0][0],lat=aircraft4.tracklis[0][1],alt=9800,heading=80,speed=900,callsign='MU5173')   
        plt.title(stamplis[i*interval],loc="right")
        if len(aircraft1.tracklis)>=i*interval:
            plot_iconandinfo_east_1(ax,lon=aircraft1.tracklis[i*interval][0],lat=aircraft1.tracklis[i*interval][1],alt=10100,heading=aircraft1.tracklis[i*interval][3],speed=aircraft1.tracklis[i*interval][4],callsign=aircraft1.callsign) 
        if len(aircraft2.tracklis)>=i*interval:
            plot_iconandinfo_east_2(ax,lon=aircraft2.tracklis[i*interval][0],lat=aircraft2.tracklis[i*interval][1],alt=10100,heading=aircraft2.tracklis[i*interval][3],speed=aircraft2.tracklis[i*interval][4],callsign=aircraft2.callsign)  
        if len(aircraft3.tracklis)>=i*interval:
            plot_iconandinfo_east_3(ax,lon=aircraft3.tracklis[i*interval][0],lat=aircraft3.tracklis[i*interval][1],alt=10100,heading=aircraft3.tracklis[i*interval][3],speed=aircraft3.tracklis[i*interval][4],callsign=aircraft3.callsign)   
        if len(aircraft4.tracklis)>=i*interval:
            plot_iconandinfo_east_4(ax,lon=aircraft4.tracklis[i*interval][0],lat=aircraft4.tracklis[i*interval][1],alt=10100,heading=aircraft4.tracklis[i*interval][3],speed=aircraft4.tracklis[i*interval][4],callsign=aircraft4.callsign) 
        # plt.show()
        plt.savefig(str(i)+'.png', dpi=300, facecolor=None, edgecolor=None,
                  orientation='portrait', papertype=None, format=None,
                  transparent=False, bbox_inches=None, pad_inches=0.1,
                  frameon=None, metadata=None)    
        plt.show()

    frames=numberofpci
    from PIL import Image
    images = [Image.open(f"{n}.png") for n in range(1,frames)]
    images[0].save('simulation3.gif', save_all=True, append_images=images[1:], duration=500, loop=0)
    # plt.legend()
animation_in_s(numberofpci=45,interval=3)
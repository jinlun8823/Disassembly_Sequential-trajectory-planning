def aggregate_cb(a,b,ra,rb):
    if min(ra,rb)<=max(ra,rb)-((b[0]-a[0])**2+(b[1]-a[1])**2)**(1/2):
        dic={ra:a,rb:b}
        center_new=dic[max(ra,rb)]
        r_new=max(ra,rb)
    else:
        vectorr1=[b[0]-a[0],b[1]-a[1]]
        absvector1=((b[0]-a[0])**2+(b[1]-a[1])**2)**(1/2)+0.0000000000000000000000001
        unit_vertor1=[vectorr1[0]/absvector1,vectorr1[1]/absvector1]
        unit_vertor2=[-vectorr1[0]/absvector1,-vectorr1[1]/absvector1]
        
        p1=[b[0]+rb*unit_vertor1[0],b[1]+rb*unit_vertor1[1]]
        p2=[a[0]+ra*unit_vertor2[0],a[1]+ra*unit_vertor2[1]]
        
        center_new=[(p1[0]+p2[0])/2,(p1[1]+p2[1])/2]
        r_new=0.5*((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)**(1/2)
    return center_new,r_new

# ###################测试程序###########################
# a=[123,32];b=[123,36];ra=0.8;rb=3
# center_new,r_new=aggregate_cb(a,b,ra,rb)
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import LinearLocator, FormatStrFormatter
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# circle1=Circle(xy=a,radius=ra,alpha=0.5,color='green')
# circle2=Circle(xy=b,radius=rb,alpha=0.5,color='yellow')
# circle3=Circle(xy=center_new,radius=r_new,alpha=0.1,color='red')
# ax.add_patch(circle1)
# ax.add_patch(circle2)
# ax.add_patch(circle3)
# ax.scatter(a[0],a[1],color='green')
# ax.scatter(b[0],b[1],color='yellow')
# ax.scatter(center_new[0],center_new[1],color='red')

# a=[113,22];b=[123,36];ra=4;rb=5
# center_new,r_new=aggregate_cb(a,b,ra,rb)
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import LinearLocator, FormatStrFormatter
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# circle1=Circle(xy=a,radius=ra,alpha=0.5,color='green')
# circle2=Circle(xy=b,radius=rb,alpha=0.5,color='yellow')
# circle3=Circle(xy=center_new,radius=r_new,alpha=0.1,color='red')
# ax.add_patch(circle1)
# ax.add_patch(circle2)
# ax.add_patch(circle3)
# ax.scatter(a[0],a[1],color='green')
# ax.scatter(b[0],b[1],color='yellow')
# ax.scatter(center_new[0],center_new[1],color='red')


'''
该程序用于聚合两个位置较近的云团
 aggregate_cb(云A中心点,云B中心点,云A半径,云B半径)
'''


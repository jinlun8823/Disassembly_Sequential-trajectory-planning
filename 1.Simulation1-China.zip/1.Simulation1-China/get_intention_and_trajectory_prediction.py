import numpy as np


# def get_intention(current_position,heading,tracklis):
#     xita=(90-heading)*2*3.1415926/360
#     if xita == np.pi/2:
#         xita = 3.1415926/2
#     k=np.tan(xita)
#     d21=100000
#     bestpoint=tracklis[0]
#     d22=110000
#     secondbestpoint=tracklis[-1]
#     for i in tracklis:
#         newd2=(i[1]-k*i[0]+k*current_position[0]-current_position[1])**2/(k**2+1)
#         if newd2 <= d21:
#             d21=newd2
#             bestpoint=i
#         elif newd2 < d22:
#             d22=newd2
#             secondbestpoint=i
    
        
    
    
    
    
    
# def get_next_position(current_position,heading,speed):
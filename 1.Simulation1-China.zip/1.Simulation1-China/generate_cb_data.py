
import numpy as np

#####v是速度矢量，反映速度大小和方向，selfposition:在新坐标系下的不动点坐标，selfpforold:老坐标系下的待求点坐标
def positionrotate2D(v,selfposition,selfpositionforold):##selfposition:在新坐标系下的不动点坐标，selfpforold:老坐标系下的待求点坐标
    vxita=np.arctan(v[1]/(v[0]+0.0000000000000000000000000000000000000000000000000001))
    xita=vxita-(np.pi)/2
    x=selfpositionforold[0]*np.cos(xita)-selfpositionforold[1]*np.sin(xita)+selfposition[0]
    y=selfpositionforold[0]*np.sin(xita)+selfpositionforold[1]*np.cos(xita)+selfposition[1]
    return x,y
# # ###################################################简单的test一下########
# a=np.random.random()#####加一个随机数，是为了模拟积雨云的动态变化

# vlis=[[0.1,0],[0.2,0.3],[0.3,0.5],[0,0.1],[-0.5,0],[0,-0.5]]

# orglis=[[0,0.4],[0.1,0.32],[0.15,0.25],[0.25,0.1],[0.35,0],[0.3,-0.05],[0.25,-0.12],
#         [0.2,-0.2],[0.1,-0.25],[0.05,-0.33],[-0.05,-0.35],[-0.1,-0.25],[-0.15,-0.18],
#         [-0.2,-0.15],[-0.25,-0.08],[-0.3,-0.05],[-0.33,0.03],[-0.25,0.1],[-0.2,0.17],
#         [-0.18,0.22],[-0.1,0.32],[-0.05,0.38],[0,0.4]]
# center_of_cb=[114.5,23.5]

# # x,y=positionrotate2D([1,0],[1,1],[-1,1])


# newlis=[]
# for i in range(len(vlis)):
#     center_of_cb=[center_of_cb[0]+vlis[i][0],center_of_cb[1]+vlis[i][1]]
#     newlisi=[]
#     for j in range(len(orglis)):
#         x,y=positionrotate2D(vlis[i],center_of_cb,orglis[j])
#         x=x+np.random.random()*0.1
#         y=y+np.random.random()*0.1
#         newlisi.append([x,y])
#     newlis.append(newlisi)
# ####################################################靠谱
        

# ################################################plot_test##########################
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为10，并存在变量里
# ax2=plt.gca()
# ax2.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax2.yaxis.set_major_locator(y_major_locator)
# ax2.set_aspect(1)
# for i in range(len(newlis)):
#     a=[];b=[]
#     for j in range(len(newlis[i])):
#         a.append(newlis[i][j][0])
#         b.append(newlis[i][j][1])
#     ax2.scatter(a,b)
# ########################################################################@@@@靠谱

#######################气团1#########################
vlis=[[0.1,0],[0.2,0.3],[0.3,0.5],[0,0.1],[-0.5,0],[0,-0.5]]
orglis=[[0,0.4],[0.05,0.36],[0.1,0.32],[0.125,0.28],[0.15,0.25],[0.2,0.189],[0.25,0.1],[0.3,0.05],[0.35,0],[0.325,-0.025],[0.3,-0.05],[0.25,-0.12],
        [0.2,-0.2],[0.15,-0.225],[0.1,-0.25],[0.075,-0.3],[0.05,-0.33],[0,-0.34],[-0.05,-0.35],[-0.075,-0.3],[-0.1,-0.25],[-0.125,-0.21],[-0.15,-0.18],
        [-0.2,-0.15],[-0.225,-0.12],[-0.25,-0.08],[-0.27,-0.069],[-0.3,-0.05],[-0.33,0.03],[-0.28,0.08],[-0.25,0.1],[-0.225,0.14],[-0.2,0.17],
        [-0.19,0.19],[-0.18,0.22],[-0.14,0.28],[-0.12,0.30],[-0.1,0.32],[-0.075,0.34],[-0.05,0.38],[-0.025,0.39],[0,0.4]]
center_of_cb=[114.5,23.5]
vlis=[]
for i in range(20):
    vx=-0.1;vy=0
    vx=vx+np.random.normal(0,0.05)
    vy=vy+np.random.normal(0,0.05)
    vlis.append([vx,vy])
    
newlis=[]
for i in range(len(vlis)):
    center_of_cb=[center_of_cb[0]+vlis[i][0],center_of_cb[1]+vlis[i][1]]
    newlisi=[]
    for j in range(len(orglis)):
        x,y=positionrotate2D(vlis[i],center_of_cb,orglis[j])
        x=x+np.random.normal(0,0.03)
        y=y+np.random.normal(0,0.03)
        newlisi.append([x,y])
    newlis.append(newlisi)

import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为10，并存在变量里
ax2=plt.gca()
ax2.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax2.yaxis.set_major_locator(y_major_locator)
ax2.set_aspect(1)
for i in range(len(newlis)):
    a=[];b=[]
    for j in range(len(newlis[i])):
        a.append(newlis[i][j][0])
        b.append(newlis[i][j][1])
    ax2.plot(a,b)

################################################################################################文件输出操作
f=open('cblist.csv','w')
f.write('pointname,lon,lat,time\n')
for k in range(len(orglis)):
    for l in range(len(newlis)):
        f.write('{0},{1},{2},{3}\n'.format('point'+str(k),newlis[l][k][0],newlis[l][k][1],1))
f.close()
        
import pandas as pd
###############################################################################
data=pd.read_csv('cblist.csv')

points = data.pointname.unique()
import time
from create_geojson import convert_tripdata,append_to_tripdata
def strtofloat(timelis):
    for i in range(len(timelis)):
        timelis[i]=time.mktime(time.strptime(timelis[i],"%Y/%m/%d %H:%M:%S"))
    
        


my_data=convert_tripdata([],'lll')

for point in points: 
    lat = data.loc[data['pointname'] == point, 'lat']
    lon = data.loc[data['pointname'] == point, 'lon']

    ftime=data.loc[data['pointname'] == point, 'time']

    lat=list(lat)
    lon=list(lon)
    alt=list(lon)
    ftime=list(ftime)
    strtofloat(ftime)

    

    d=[]
    for j in range(len(lon)):
        d.append((lon[j],lat[j],alt[j],ftime[j]))



    
    my_data=append_to_tripdata(my_data,point,d)

    # print('end')

    
    
my_data['features'].pop(0)
    
import json
with open('cbdata.json', 'w') as f:
    json.dump(my_data,f)

#############################################################################生成用于计算的列表





























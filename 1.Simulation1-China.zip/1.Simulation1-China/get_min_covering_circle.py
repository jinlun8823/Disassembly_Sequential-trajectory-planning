import numpy as np

def get_centerpoint(lis):###################获得不规则闭合多边形的形心
        area = 0.0
        x,y = 0.0,0.0
        a = len(lis)
        for i in range(a):
            lat = lis[i][0] #weidu
            lng = lis[i][1] #jingdu
            if i == 0:
                lat1 = lis[-1][0]
                lng1 = lis[-1][1]
            else:
                lat1 = lis[i-1][0]
                lng1 = lis[i-1][1]
            fg = (lat*lng1 - lng*lat1)/2.0
            area += fg
            x += fg*(lat+lat1)/3.0
            y += fg*(lng+lng1)/3.0
        x = x/(area+0.00000000000000000000000000000001)
        y = y/(area+0.00000000000000000000000000000001)
        return x,y
def get_r(centerofcircle,lis):
        lisr=[]
        for i in lis:
            r=((i[0]-centerofcircle[0])**2+(i[1]-centerofcircle[1])**2)**(1/2)
            lisr.append(r)
        return max(lisr)
#############整体封装##########
def get_center_and_radius(polygonlis):
    center=get_centerpoint(polygonlis)
    r=get_r(center,polygonlis)
    return center,r
# center,r=get_center_and_radius([[10,10],[20,10],[20,30],[14,15],[10,20],[10,10]])
   
# #################获取不规则多边形最小覆盖圆测试程序    
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import LinearLocator, FormatStrFormatter
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# polylis=[[10,10],[20,10],[20,30],[14,15],[10,20],[10,10]]############polylis为不规则多边形，点按顺时针或逆时针顺序闭合排列
# center=get_centerpoint(polylis)
# r=get_r(center,polylis)  
# circle=Circle(xy=(center[0],center[1]),radius=r,alpha=0.1)
# x=[];y=[]
# for i in polylis:
#     x.append(i[0]);y.append(i[1])
# ax.plot(x,y)
# ax.scatter(center[0],center[1],color='red')    
# ax.add_patch(circle)
# ###############################测试成功
    

'''
最终调用函数为    get_center_and_radius()
polygonlis数据格式:list   例如:[[lon1,lat1],[lon2,lat20,...,[lonn,latn]]]   
顺时针或逆时针有向列表，首末点闭合
'''
    
    
    
    
    
    
    
    
from class_aircraft import Aircraft
from generate_track_basedon_critical_points import get_next_track_point,get_instruction,get_next_track4,get_heading
from multi_cb_conflicts_resolve import get_c_lis
import json
import numpy as np
import random
import time
import datetime
with open('flightplan2.json','r',encoding='utf-8') as f:
    original_plan_dict = json.load(f)
#############根据时间戳生成初始状态的函数##############
def get_current_position(flightplan,timestamp):
    # flightplan=original_plan_dict['CA102'];timestamp='2019-05-13 08:59:31'
    for i in range(len(flightplan)-1):
        if flightplan[i][3] <= timestamp <= flightplan[i+1][3]:
            # print(i)
            # a=time.mktime(time.strptime(timestamp,"%Y-%m-%d %H:%M:%S"))
            a=datetime.datetime.strptime(timestamp,"%Y-%m-%d %H:%M:%S")
            b=datetime.datetime.strptime(flightplan[i][3],"%Y-%m-%d %H:%M:%S")
            # print(flightplan[i+1][3])
            c=datetime.datetime.strptime(flightplan[i+1][3] ,"%Y-%m-%d %H:%M:%S")
            delta1=a-b
            delta2=c-a
            rate1=delta1/(delta1+delta2)
            rate2=delta2/(delta1+delta2)
            lon=rate2*flightplan[i][0]+rate1*flightplan[i+1][0]
            lat=rate2*flightplan[i][1]+rate1*flightplan[i+1][1]
            # cp=[lon,lat]
            return [[lon,lat],flightplan[i+1]]
        else:
            continue
    # print('None')
    return [None,None]
#############随机生成初始飞行高度层的函数(遵循东单西双原则)#############
def generate_flight_level(current_point,next_point):
    heading=get_heading(current_point,next_point)
    if 0 < heading <= 180:
        levellis = [11900,11300,10700,10100,9500,8900,8100,7500,6900,6300,5700,5100]
        height=random.choice(levellis)
    else:
        levellis = [12200,11600,11000,10400,9800,9200,8400,7800,7200,6600,6000,5400,4800]
        height=random.choice(levellis)
    return height

import datetime
 
def getFutureTime(timestamp,it,format='%Y-%m-%d %H:%M:%S'):
    '''
    以给定时间戳为基准，前进 hours 个小时得到对应的时间戳
    '''
    now_time=datetime.datetime.strptime(timestamp,'%Y-%m-%d %H:%M:%S')
    for i in range(it):
        now_time+=datetime.timedelta(seconds=4)
    next_timestamp=now_time.strftime('%Y-%m-%d %H:%M:%S')
    # print ('next_timestamp: ',next_timestamp)
    return next_timestamp
timestamp='2023-05-13 08:00:00'
stamplis=[]
for i in range(3600):
    tt=getFutureTime(timestamp, it=i, format='%Y-%m-%d %H:%M:%S')
    stamplis.append(tt)
    

'''
步骤一：获取哪些飞机进入空域----已完成

步骤二: 计算未来几个关键航迹点(比如：4个)

步骤三：生成引导指令下的绕飞航迹(/4s)

步骤四：判定，是否到达目的地，若到达，则从Alis中删除
'''

##################所有的飞机
Clis=[]
Uall=set()
for i in original_plan_dict.keys():
    Uall.add(i)
for stamp in stamplis:
    A=set()
    timestamp=stamp 
    for jj in original_plan_dict.keys():
        for kk in range(len(original_plan_dict[jj])-1):
            if original_plan_dict[jj][kk][3] <= timestamp <= original_plan_dict[jj][kk+1][3]:    
                A.add(jj)
    C=A.intersection(Uall)
    Clis.append(C)
    Uall=Uall-A
U=set()
for j in Clis:
    U =  U.union(j)
######至此，Clis为每分钟出现的航空器
Alis=[]
finalAlis=[]
with open('flightplan2.json','r',encoding='utf-8') as f:
    original_plan_dict = json.load(f)
with open('cbjson.json','r',encoding='utf-8') as f:
    cbjson= json.load(f)
for t in range(len(stamplis)):
    print(t)
    cloudlis=cbjson[str(t)]
    ##################每个时间戳加入航空器##########
    craftin=Clis[t]
    if craftin !={}:
        for a in craftin:
            flightplan=original_plan_dict[a]
            currentandnext=get_current_position(original_plan_dict[a],timestamp=stamplis[t])
            # print(currentandnext)
            c = Aircraft(callsign=a,flightplan=original_plan_dict[a],critical_track_points=original_plan_dict[a],
                                  current_position=[currentandnext[0][0],currentandnext[0][1],stamplis[t]],
                                  height=generate_flight_level(currentandnext[0],[currentandnext[1][0],currentandnext[1][1]]),
                                  heading=get_heading(currentandnext[0],[currentandnext[1][0],currentandnext[1][1]]))
            # flagg=0
            # for jj in cloudlis:
            #     if (currentandnext[0][0]-jj[0])**2 + (currentandnext[0][1]-jj[1])**2 <= (jj[2])**2:
            #         flagg=1
            #         break    
            #     else:
            #         continue
            # if flagg ==0:
            Alis.append(c)
    ###################计算未来几个关键航迹点(比如：4个)################
    for craft in Alis:
        critical_tralis=craft.flightplan
        i_t= get_c_lis(cloudlis,critical_tralis)  
        if i_t == 'diversion':
            Alis.remove(craft)
            # finalAlis.append(craft)
            continue
        else:
            craft.add_critical_track_points(i_t)
        next_point = get_next_track_point(current_point=craft.current_position,tracklis=craft.critical_track_points,v=craft.current_v,height=craft.height)
        if next_point == 'arrive':
            Alis.remove(craft)
            finalAlis.append(craft)
            continue
        elif next_point=='abnormal':
            next_point=[craft.critical_track_points[-1][0],craft.critical_track_points[-1][1]]
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point)
            # print(instruction['timeinterval'])
        else:
            instruction = get_instruction(current_point=craft.current_position,next_point=next_point['point0'])
            # print(instruction['timeinterval'])
        craft.doing_current_instruction(instruction,stamplis[t])
# #######################################################################################################################
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# from matplotlib.patches import Polygon
# from mpl_toolkits.basemap import Basemap
# # zi = griddata(np.array(x), np.array(y), np.array(Temperature), xi, yi, interp='linear')
# fig = plt.figure(figsize=(16,8))
# ax = fig.add_axes([0.1,0.1,0.8,0.8])
# # 绘图的经纬度范围，经度范围113.4-115.8,纬度范围37.3-38.9
# plt.rcParams["font.family"]='Times New Roman'######全局字体
# plt.rcParams["font.size"]=18.0##########小四
# plt.rcParams["text.color"]='black'#############图例和标题文本字体颜色（）
# plt.rcParams["mathtext.fontset"]='stix'
# map2 = Basemap(llcrnrlon=70,llcrnrlat=16,urcrnrlon=135,urcrnrlat=55, lat_1=20, lat_2=35, lon_0=110,ax=ax)#创建一个地图，设定经纬度
# # map2.drawcoastlines()#绘制海岸线
# # map2.drawcountries(linewidth=1.5)#画上国家线
# map2.drawlsmask()#####etopo地形图，shadedrelief浮雕,bluemarble,卫星图,drawlsmask()黑白图.warpimage()是另一种卫星图
# # for info, shape in zip(map2.comarques_info, map2.comarques):
# #     x, y = zip(*shape) 
# #     map2.plot(x, y, marker=None,color='red')
# # map2.readshapefile('gadm36_CHN_2','city',drawbounds=True)
# # map2.readshapefile('gadm36_CHN_1','city',drawbounds=True,color='black')#加载行政区划文件CHN1:省。CHN2：市，CHN3：区
# # map2.readshapefile('gadm36_TWN_1','city',drawbounds=True,color='black')
# # map2.fillcontinents(color='skyblue', lake_color='none')
# ###################################
# parallels = np.arange(0.,90,5.) 
# map2.drawparallels(parallels,labels=[1,0,0,0],fontsize=15) # 绘制纬线
# ##################################
# meridians = np.arange(70.,140.,5.)
# map2.drawmeridians(meridians,labels=[0,0,0,1],fontsize=15) # 绘制经线
# #################################
# ax.axis('off')
# plt.gca().xaxis.set_major_locator(plt.NullLocator())
# plt.gca().yaxis.set_major_locator(plt.NullLocator())
# plt.subplots_adjust(top=1, bottom=0, left=0, right=1, hspace=0, wspace=0)
# plt.margins(0, 0)
# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='red')
#     ax.add_patch(circle1)
# for craft in finalAlis:
#     x=[];y=[]
#     for j in craft.tracklis:
#         x.append(j[0])
#         y.append(j[1])
#     plt.plot(x,y,color='green')
# for craft in Alis:
#     x=[];y=[]
#     # if craft.callsign=='HU7287':
#     for j in craft.tracklis:
#         x.append(j[0])
#         y.append(j[1])
#     plt.plot(x,y,color='blue')
# for craft in finalAlis:
#     x=[];y=[]
#     for j in craft.flightplan:
#         x.append(j[0])
#         y.append(j[1])
#     plt.scatter(x,y,color='yellow')
# for craft in Alis:
#     x=[];y=[]
#     for j in craft.flightplan:
#         x.append(j[0])
#         y.append(j[1])
#     plt.scatter(x,y,color='yellow')
#####################################转化成航迹数据测试一下###################
f=open('testtrack.csv','w')######打开一个文件
f.write('craftname,lon,lat,alt,time\n')  
for i in Alis:
    for j in i.tracklis[1::]:
        f.write('{0},{1},{2},{3},{4}\n'.format(i.callsign,j[0],j[1],0,j[3]))
for i in finalAlis:
    for j in i.tracklis[1::]:
        f.write('{0},{1},{2},{3},{4}\n'.format(i.callsign,j[0],j[1],0,j[3]))

f.close()
##############3333333########################
from geojson import MultiLineString
def convert_tripdata(lis,name):
    a=MultiLineString(lis)
    a['features']=[{'type':'Feature','properties':{"name":name},"geometry":{"type":a['type'],"coordinates":a['coordinates']}}]
    a['features'][0]['geometry']['type']='LineString'
    a['type']='FeatureCollection'
    a.pop('coordinates')
    return a
def append_to_tripdata(ori_json,name,linelis):
    md=convert_tripdata(linelis,name)
    ori_json['features'].append(md['features'][0])
    return ori_json
import pandas as pd
df=pd.read_csv('testtrack.csv')

flights = df.craftname.unique()


def strtofloat(timelis):
    for i in range(len(timelis)):
        timelis[i]=time.mktime(time.strptime(timelis[i],"%Y-%m-%d %H:%M:%S"))

my_data=convert_tripdata([],'lll')
k=0
flights=list(flights)

for flight in flights: 
    if flight == 'SC4918':
        print('sss')
        continue
    lat = df.loc[df['craftname'] == flight, 'lat']
    lon = df.loc[df['craftname'] == flight, 'lon']
    alt=df.loc[df['craftname'] == flight, 'alt']
    ftime=df.loc[df['craftname'] == flight, 'time']

    lat=list(lat)
    lon=list(lon)
    alt=list(alt)
    ftime=list(ftime)
    strtofloat(ftime)
    flag= False
    
    d=[]

    for j in range(len(lon)):
            
        d.append((lon[j],lat[j],alt[j],ftime[j]))

            
        #     if  abs(lon[j+1]-lon[j]) >= 5 :
        #         flag= True
        #         break
        # if flag= False:
        #     for j in range(len(lon)):
        #         if j % 10 == 0:
        #             d.append((lon[j],lat[j],alt[j],ftime[j]))
        # else:   
        #     if flag= True:
        #         e.append((lon[j],lat[j],alt[j],ftime[j]))
        #     else:
        #         if j % 10 == 0:
        #             d.append((lon[j],lat[j],alt[j],ftime[j]))
            
    k+=1
    print(k)
    # if  flight == 'CA1202' or 'SC8724':
    #     continue
    # else:
    my_data=append_to_tripdata(my_data,flight,d)

    # print('end')

    
    
my_data['features'].pop(0)####把第一个初始的去掉
    
import json
with open('tripdataofaircraft4.json', 'w') as f:
    json.dump(my_data,f)

# f.close()

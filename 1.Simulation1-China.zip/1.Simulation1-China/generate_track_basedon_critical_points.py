import numpy as np

def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d
def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita
###################测试#################
# AA=[0,0]
# xitalis=[]
# for i in np.arange(0,2*3.1415926535897932638,0.01):
#     xita=get_heading(AA,[np.cos(i),np.sin(i)])
#     xitalis.append(xita)
# import matplotlib.pyplot as plt
# plt.plot(xitalis)
def get_next_position(current_point,tracklis,v):###生成4s后下一个航空器位置,v:km/h
    # print(current_point,tracklis,v)
    flag=0
    for i in range(len(tracklis)-1):
        if min(tracklis[i][0],tracklis[i+1][0])<=current_point[0]<=max(tracklis[i][0],tracklis[i+1][0]) and min(tracklis[i][1],tracklis[i+1][1])<=current_point[1]<=max(tracklis[i][1],tracklis[i+1][1]):
            flag=1
            vx=(tracklis[i+1][0]-current_point[0])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
            vy=(tracklis[i+1][1]-current_point[1])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
            vector=[vx,vy]###单位向量
            x=current_point[0]+vx*(v/110)*4/3600
            y=current_point[1]+vy*(v/110)*4/3600
            heading=get_heading(current_point,[tracklis[i+1][0],tracklis[i+1][1]])##航向
            next_position=[x,y,heading,4]
            return next_position####[经度，纬度，航向，时间间隔]
        else:
            continue
    if flag==0:
        return '读取航迹意图失败'
##############测试#########################################
# tracklis=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], 
#           [113.851058959961, 23.0928325653076], [113.415802001953, 24.1916389465332], 
#           [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#           [110.64373175634925, 25.995402602531787], [108.72721862793, 26.0091667175293],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764],
#           [106.780281066895, 26.7866668701172],[106.375274658203, 27.1991672515869]]
# current_point=[114.133331298828, 22.5433330535889]
# currentlis=[]    
# # next_position=get_next_position(current_point,tracklis,v=800)
# while (current_point[0]-tracklis[-1][0])**2+(current_point[1]-tracklis[-1][1])**2>0.02**2:
#     next_position=get_next_position(current_point,tracklis,v=750)
#     currentlis.append([next_position[0],next_position[1],next_position[2]])
#     current_point=next_position
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# x=[];y=[];z=[]
# for i in currentlis:
#     x.append(i[0])
#     y.append(i[1])
#     z.append(i[2])
# ax.scatter(x,y,color='red',s=1)    
# x=[];y=[]
# for i in tracklis:
#     x.append(i[0])
#     y.append(i[1])
# ax.scatter(x,y,color='blue')  

############判断下一个点的航迹意图
def get_next_track_point(current_point,tracklis,v,height):#######到达下一个点的位置，速度、高度、时间
#
    tracklis=tracklis.copy()

    cc = tracklis;dellis=[]
    for i in range(len(cc)-1):
        if (cc[i][0]-cc[i+1][0])**2 + (cc[i][1]-cc[i+1][1])**2 <= (1.5/110)**2:
          dellis.append(i)
    tracklis = [n for i, n in enumerate(tracklis) if i not in dellis]      
#
    # a = b
    # print(a)
    if (current_point[0]-tracklis[-1][0])**2+(current_point[1]-tracklis[-1][1])**2 <= (1/110)**2:
        return 'arrive'###已经到了
    # if (current_point[0]-tracklis[-1][0])**2+(current_point[1]-tracklis[-1][1])**2 <= (6/110)**2:
    for i in range(len(tracklis)-1):
        if (current_point[0]-tracklis[i][0])**2 + (current_point[1]-tracklis[i][1])**2 <= (1/110)**2:
            
            # print('there1')
            # print(current_point)
            # print(tracklis[i])
            if i <= len(tracklis)-2:
                if (current_point[0]-tracklis[i+1][0])**2 + (current_point[1]-tracklis[i+1][1])**2 <= (1/110)**2:
                    next_point = tracklis[i+2]
                else:
                    next_point = tracklis[i+1]
            else:
                next_point = tracklis[i+1]
            # print(next_point)
            d = distance(current_point,next_point)
            t = d*3600/v
            # print('first',next_point)
            return {'point0':next_point,'heading':0,'speed':v,'height':height,'time':t}
        else:
            continue
    for i in range(len(tracklis)-1):
        # print('second',i)
        if abs(tracklis[i+1][0]-tracklis[i][0])>=0.03 and abs(tracklis[i+1][1]-tracklis[i][1])>=0.03:
            # print('there2')
            if min(tracklis[i][0],tracklis[i+1][0]) <= current_point[0] <= max(tracklis[i][0],tracklis[i+1][0]) and min(tracklis[i][1],tracklis[i+1][1]) <= current_point[1] <= max(tracklis[i][1],tracklis[i+1][1]):
                next_point = tracklis[i+1]
                d = distance(current_point,next_point)
                t = d*3600/v
                # print('second',next_point)
                return {'point0':next_point,'heading':0,'speed':v,'height':height,'time':t}
        
        else:
            # print('there3')
            if abs(tracklis[i+1][0]-tracklis[i][0]) < 0.03:
                # print('there4')
                if min(tracklis[i][0],tracklis[i+1][0])-0.02 <= current_point[0] <= max(tracklis[i][0],tracklis[i+1][0])+0.02 and min(tracklis[i][1],tracklis[i+1][1]) <= current_point[1] <= max(tracklis[i][1],tracklis[i+1][1]):
                    next_point = tracklis[i+1]
                    d = distance(current_point,next_point)
                    t = d*3600/v
                    # print('second',next_point)
                    return {'point0':next_point,'heading':0,'speed':v,'height':height,'time':t}
            elif abs(tracklis[i+1][1]-tracklis[i][1]) < 0.03:
                # print('there5')
                if min(tracklis[i][0],tracklis[i+1][0]) <= current_point[0] <= max(tracklis[i][0],tracklis[i+1][0]) and min(tracklis[i][1],tracklis[i+1][1])-0.02 <= current_point[1] <= max(tracklis[i][1],tracklis[i+1][1])+0.02:
                    next_point = tracklis[i+1]
                    d = distance(current_point,next_point)
                    t = d*3600/v
                    # print('second',next_point)
                    return {'point0':next_point,'heading':0,'speed':v,'height':height,'time':t}

    # print('attention here')#####偶尔存在丢失航迹意图的情况，这和timestamp步长有关，也和判断到达距离有关
    # print(current_point)
    return "abnormal"####偏离太多的情况
'''
几个时间戳（距离容差）的问题：
if (current_point[0]-tracklis[i][0])**2 + (current_point[1]-tracklis[i][1])**2 <= (1.5/110)**2
这里的(1.5/110)调的越大，越不准确，但最小小到最大timestamp的距离v*t，同时，太小了也不利于飞行员控制，即提前量不够

abs(tracklis[i+1][0]-tracklis[i][0])>=0.03 and abs(tracklis[i+1][1]-tracklis[i][1])>=0.03
这里的度数0.03是经纬度容差，太小了会使得过关键点后丧失航迹意图，太大会导致往返，即同时属于两种航迹意图。

'''    
# ###############################测试程序#############################

# tracklis=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], 
#           [113.851058959961, 23.0928325653076], [113.415802001953, 24.1916389465332], 
#           [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#           [110.64373175634925, 25.995402602531787], [108.72721862793, 26.0091667175293],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764],
#           [106.780281066895, 26.7866668701172],[106.375274658203, 27.1991672515869]]
# current_point=[113.451058959961, 23.6928325653076]
# next_point=get_next_track_point(current_point,tracklis,v=800,height=9800)
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in tracklis:
#     x.append(i[0])
#     y.append(i[1])
# # x=[];y=[]
# # for i in range(len(next_point)):
# #     x.append(next_point[i]['point0'][0])
# #     y.append(next_point[i]['point0'][1])
# ax.scatter(x,y,color='blue')  
# ax.scatter(next_point['point0'][0],next_point['point0'][1],color='red',s=10)  
# ax.scatter(current_point[0],current_point[1],color='green',s=10)
##########################如果这个函数读取航迹意图失败了，就没有必要往下走啦

########################生成意图对应的引导指令#####################只到达下一个航路点
instruction={'speed':1050,'flightlevel':10400,'heading':60,'timeinterval':1}
#############规避云的时候调节heading,然后是flightlevel和speed
def get_instruction(current_point,next_point):
    instruction={'speed':1000,'flightlevel':9850,'heading':333,'timeinterval':4}###########默认值
    heading=get_heading(current_point,next_point)
    instruction['heading']=heading
    
    #flightlevel=get_flight_level()
    #instruction['flightlevel']=flightlevel
    
    #speed=get_speed()
    #instruction['speed']=speed
    
    # print(instruction)
    return instruction
####################################################################
def get_next_track9(current_point,next_point,tracklis,v,height):######未来9个关键航迹节点
    index=tracklis.index(next_point)
    next_c_point=[];t=0
    if len(tracklis)- index >= 9:
        for k in range(9):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            # print(dis)
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    else:
        for k in range(len(tracklis)-index):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point

def get_next_track4(current_point,next_point,tracklis,v,height):######未来4个关键航迹节点
    index=tracklis.index(next_point)
    next_c_point=[];t=0
    if len(tracklis)- index >= 4:
        for k in range(4):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            # print(dis)
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    else:
        for k in range(len(tracklis)-index):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
def get_next_track2(current_point,next_point,tracklis,v,height):######未来2个关键航迹节点
    index=tracklis.index(next_point)
    next_c_point=[];t=0
    if len(tracklis)- index >= 2:
        for k in range(2):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            # print(dis)
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    else:
        for k in range(len(tracklis)-index):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
##########测试实验1##############
# tracklis=[[114.133331298828, 22.5433330535889], [113.851058959961, 23.0928325653076], 
#             [113.415802001953, 24.1916389465332], [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#             [110.77564239502, 24.6709175109863], [110.212219238281, 25.2047214508057], [109.608329772949, 25.7749996185303], 
#             [108.72721862793, 26.0091667175293], [108.39722442627, 26.0966663360596], [107.142776489258, 26.6330547332764], 
#             [106.780281066895, 26.7866668701172], [106.375274658203, 27.1991672515869], [106.062774658203, 27.5147228240967], 
#             [105.854721069336, 27.731388092041], [105.421417236328, 28.1706657409668], [105.042221069336, 28.4466667175293],
#             [104.753051757813, 28.6572227478027], [104.555809020996, 28.7995834350586], [104.304168701172, 29.9294452667236],
#             [104.391418457031, 30.8727493286133], [104.378723144531, 31.2490005493164], [104.366668701172, 31.4333324432373],
#             [104.316665649414, 32.4099998474121], [104.294998168945, 32.8600006103516], [104.270835876465, 33.3572235107422], 
#             [104.191390991211, 34.9758338928223], [104.151947021484, 35.7758331298828], [104.124725341797, 36.2794456481934], 
#             [104.112503051758, 36.5294456481934], [103.283889770508, 36.9369430541992], [102.439720153809, 37.3583335876465], 
#             [102.035278320313, 37.4375], [101.685554504395, 37.5047225952148], [101.316108703613, 37.6538887023926], 
#             [100.918891906738, 37.8291664123535], [100.011665344238, 38.2171669006348], [97.6258316040039, 39.2294425964355], 
#             [97.033332824707, 39.4669456481934], [96.6227798461914, 39.6308326721191], [95.1452789306641, 40.2000007629395], 
#             [94.8666687011719, 40.3058319091797], [93.8480529785156, 40.9150009155273], [91.6941680908203, 42.5183334350586],
#             [89.3930587768555, 43.5577774047852], [87.9815826416016, 44.171028137207], [88.2044448852539, 44.5552787780762], 
#             [88.317497253418, 44.7486114501953], [88.9844436645508, 45.8777770996094], [88.0850296020508, 47.7475814819336],
#             [87.466667175293, 49.091667175293]]
# callsign='CSN634'
# current_point=[114.133331298828, 22.5433330535889]
# next_point=get_next_track_point(current_point,tracklis,900,9800)
# # print(tracklis)
# next_c_point=get_next_track9(current_point,next_point['point0'],tracklis,v=800,height=9800)
# # print('\n',tracklis)
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# xo=[];yo=[]
# for i in tracklis:
#     xo.append(i[0]);yo.append(i[1])

# fig=plt.figure()
# ax=fig.add_subplot(321)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i+1)][0])
#     y.append(next_c_point[i]['point'+str(i+1)][1])
# ax.scatter(x,y,color='blue')  
# ax.plot(xo,yo)

# #############不够的情况
# current_point=[87.9815826416016, 44.171028137207]
# next_point=get_next_track_point(current_point,tracklis,900,9800)
# next_c_point=get_next_track9(current_point,next_point['point0'],tracklis,v=800,height=9800)

# ax=fig.add_subplot(322)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i+1)][0])
#     y.append(next_c_point[i]['point'+str(i+1)][1])
# ax.scatter(x,y,color='blue')  
# ax.plot(xo,yo)
# #############get_next_track4测试，够的情况
# current_point=[104.151947021484, 35.7758331298828]
# next_point=get_next_track_point(current_point,tracklis,900,9800)
# next_c_point=get_next_track4(current_point,next_point['point0'],tracklis,v=800,height=9800)
# ax=fig.add_subplot(323)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i+1)][0])
#     y.append(next_c_point[i]['point'+str(i+1)][1])
# ax.scatter(x,y,color='blue')  
# ax.plot(xo,yo)

# #############get_next_track4测试，不够的情况
# current_point=[88.9844436645508, 45.8777770996094]
# next_point=get_next_track_point(current_point,tracklis,900,9800)
# next_c_point=get_next_track4(current_point,next_point['point0'],tracklis,v=800,height=9800)
# ax=fig.add_subplot(324)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i+1)][0])
#     y.append(next_c_point[i]['point'+str(i+1)][1])
# ax.scatter(x,y,color='blue')  
# ax.plot(xo,yo)

# #############get_next_track2测试，不够的情况
# current_point=[101.685554504395, 37.5047225952148]
# next_point=get_next_track_point(current_point,tracklis,900,9800)
# next_c_point=get_next_track2(current_point,next_point['point0'],tracklis,v=800,height=9800)
# ax=fig.add_subplot(325)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i+1)][0])
#     y.append(next_c_point[i]['point'+str(i+1)][1])
# ax.scatter(x,y,color='blue')  
# ax.plot(xo,yo)
# #############get_next_track2测试，不够的情况
# current_point= [88.0850296020508, 47.7475814819336]
# next_point=get_next_track_point(current_point,tracklis,900,9800)
# next_c_point=get_next_track2(current_point,next_point['point0'],tracklis,v=800,height=9800)
# ax=fig.add_subplot(326)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i+1)][0])
#     y.append(next_c_point[i]['point'+str(i+1)][1])
# ax.scatter(x,y,color='blue')  
# ax.plot(xo,yo)

# ##########测试实验2##############
# tracklis=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], 
#           [113.851058959961, 23.0928325653076], [113.415802001953, 24.1916389465332], 
#           [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#           [110.64373175634925, 25.995402602531787]]
# current_point=[114.133331298828, 22.5433330535889]
# next_c_point=get_next_track(current_point,tracklis,v=800,height=9800)
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i)][0])
#     y.append(next_c_point[i]['point'+str(i)][1])
# ax.scatter(x,y,color='blue')  
###########测试实验3##############
# tracklis=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], 
#           [113.851058959961, 23.0928325653076]]
# current_point=[114.133331298828, 22.5433330535889]
# next_c_point=get_next_track(current_point,tracklis,v=800,height=9800)
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i)][0])
#     y.append(next_c_point[i]['point'+str(i)][1])
# ax.scatter(x,y,color='blue')  
###########测试实验4##############
# tracklis=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684]]
# current_point=[114.03331298828, 22.7433330535889]
# next_c_point=get_next_track(current_point,tracklis,v=800,height=9800)
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in range(len(next_c_point)):
#     x.append(next_c_point[i]['point'+str(i)][0])
#     y.append(next_c_point[i]['point'+str(i)][1])
# ax.scatter(x,y,color='blue')  

# ####################连续测试实验5################
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# tracklis=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], 
#           [113.851058959961, 23.0928325653076], [113.415802001953, 24.1916389465332], 
#           [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#           [110.64373175634925, 25.995402602531787], [108.72721862793, 26.0091667175293],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764],
#           [106.780281066895, 26.7866668701172],[106.375274658203, 27.1991672515869],
#           [106.062774658203, 27.5147228240967],[105.854721069336, 27.731388092041],
#           [105.421417236328, 28.1706657409668],[105.042221069336, 28.4466667175293]]
# current_point=[114.133331298828, 22.5433330535889]
# while len(tracklis)>1:
#     next_c_point=get_next_track(current_point,tracklis,v=800,height=9800)
#     print(next_c_point,'\n')
#     x=[];y=[]
#     for i in range(len(next_c_point)):
#         x.append(next_c_point[i]['point'+str(i)][0])
#         y.append(next_c_point[i]['point'+str(i)][1])
#     fig=plt.figure()
#     ax=fig.add_subplot(111)
#     ax.xaxis.set_major_locator(x_major_locator)
#     #把x轴的主刻度设置为1的倍数
#     ax.yaxis.set_major_locator(y_major_locator)
#     ax.set_aspect(1) 
#     ax.scatter(x,y,color='orange') 
#     tracklis.remove(current_point)
#     current_point=tracklis[0]
def get_predicted_track(current_point,tracklis,v,height):######未来分钟的航迹，每4s一个点
    next_eight_minutes_t_points = []
    current_point_iterate=current_point
    t=0
    for i in range(24):
        if get_next_position(current_point_iterate,tracklis,v) =='读取航迹意图失败':
            return next_eight_minutes_t_points
        else:
            t=t+4
            mid=get_next_position(current_point_iterate,tracklis,v)
            current_point_iterate=[mid[0],mid[1]]
            ky='point'+str(i)
            next_eight_minutes_t_points.append({ky:[mid[0],mid[1]],'time':t,'speed':v,'height':height,'heading':mid[3]})
    return next_eight_minutes_t_points

#############测试###############即将到达目的地
tracklis=[[105.421417236328, 28.1706657409668],[105.042221069336, 28.4466667175293]]
current_point=[105.221417236328, 28.2706657409668]

# pred_track1=get_predicted_track(current_point,tracklis,v=800,height=9800)
#############测试###############很久才到目的地
tracklis=[[112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
          [110.64373175634925, 25.995402602531787], [108.72721862793, 26.0091667175293],
          [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]
current_point=[112.83528137207, 24.2983341217041]

pred_track2=get_predicted_track(current_point,tracklis,v=900,height=9800)
pred_track3=get_predicted_track(current_point,tracklis,v=8000,height=9800)
# 画图
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为1，并存在变量里
fig=plt.figure()
ax=fig.add_subplot(111)
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
ax.set_aspect(1)    
x=[];y=[]
for i in tracklis:
    x.append(i[0])
    y.append(i[1])
ax.scatter(x,y,color='blue',label='flight plan')  
x=[];y=[]
for i in range(len(pred_track2)):
    x.append(pred_track2[i]['point'+str(i)][0])
    y.append(pred_track2[i]['point'+str(i)][1])
ax.scatter(x,y,color='green',label='predicted1')
x=[];y=[]
for i in tracklis:
    x.append(i[0])
    y.append(i[1])
ax.scatter(x,y,color='blue')  
x=[];y=[]
for i in range(len(pred_track3)):
    x.append(pred_track3[i]['point'+str(i)][0])
    y.append(pred_track3[i]['point'+str(i)][1])
ax.scatter(x,y,color='red',alpha=0.5,label='predicted2')
plt.legend()


'''这页包含三个主程序
1.获取航空器下一时间戳位置：get_next_position(current_point=[lon,lat],tracklis,v):###生成4s后下一个航空器位置,v:km/h,返回next_position####[经度，纬度，航向，时间间隔=4s]
2.获取航空器未来10个航迹点： get_next_track(current_point,tracklis,v,height)，返回[{'point0':,'heading':,'speed':,'height':,time':},{},{},{}]格式航迹
3.预测未来8分钟航迹：get_predicted_track(current_point,tracklis,v,height，返回[{'point0':,'heading':,'speed':,'height':,'time':},{},{},{}]格式航迹
    注意：此处航迹数据[{},{},{}]中的time是时间差（相对时间time-delta），用程序运行当前时间加上这个time就是航空器预计过点年月日时分秒时间
'''




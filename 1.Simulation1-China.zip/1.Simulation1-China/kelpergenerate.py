# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 20:15:21 2022

@author: 13043
"""


import dash
import pandas as pd
from keplergl import KeplerGl
from keplergl import data_to_json
import json
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from create_geojson import convert_multiline,convert_multipolygon
import numpy as np
import pandas as pd
# zi = griddata(np.array(x), np.array(y), np.array(Temperature), xi, yi, interp='linear')

# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 15:28:23 2019

@author: atc
"""



with open('China2.json','r',encoding='utf-8') as f:
    raw1 = json.load(f)

# with open('D:\\testkpl\gadm36_TWN_0.json','r',encoding='utf-8') as f:
#     raw2 = json.load(f)
# raw1.head()

config = {
'version': 'v1',
'config': {
    'mapState': {
        'latitude': 29.75,
        'longitude': 107.4,
        'zoom': 3},
    'visState': {'filters':[],
        'layers':[{
            'type':'trip',
            'config':{
            'dataId':'trip1',
            'label':'Trip',
            'color':[0,0,0],
            'strokeWidth':5,
            'trailLength':1000,
            'visConfig':{
                'strokeWidth':5,
                'trailLength':1000}
            }
        },
          {
              'type':'Polygon',
              'config':{
              'dataId':'sectors',
              'visConfig':{'filled':False,
                           
                  },
              'filled':False,

              }
          }   
            ],
        'interactionConfig':{
            'tooltip':{
                
                }
            }
        }
    }
}

# config = {
#     'config': {
#         'mapState': {
#             'latitude': 29.75,
#             'longitude': 107.4,
#             'zoom': 3},
        
        
    
    
#     }
# }
 # 生成Kepler.gl网页

import json
# test.to_csv('D:/test.csv') # 如果生成excel，可以用to_excel
# import pandas as pd 
# raw0=pd.read_excel('testpoint.xlsx')
# with open('testpoint.xlsx','r',encoding='utf-8') as f:
#     raw0 = json.load(f)
map1=KeplerGl(height=800, data={})
with open('tripdata3.json','r',encoding='utf-8') as f:
    raw4 = json.load(f)
map1.add_data(data=raw4,name='trip1')
with open('China2.json','r',encoding='utf-8') as f:
    raw1 = json.load(f)
map1.add_data(data=raw1, name='China')
                                
with open('alllines.json','r',encoding='utf-8') as f:
    raw2 = json.load(f)
map1.add_data(data=raw2,name='airlines')

# for key in sectors.keys():
#     i=2
#     with open(str(key)+'.json','r',encoding='utf-8') as f:
#         raw1 = json.load(f)
#     map1.add_data(raw1,'layer'+str(i))
#     i=i+1

with open('sectors.json','r',encoding='utf-8') as f:
    raw3 = json.load(f)
map1.add_data(data=raw3,name='sectors')



map1.config=config

# print(map1.config)

# map1.show(data={'layer1': raw1,'layer2':raw2}, config=None, read_only=False, center_map=True)
map1.save_to_html(file_name='空域与航路结构图.html',center_map=False,read_only=False) # 导出网页
# a=map1.config
# -*- coding: utf-8 -*-

# """
# @File    : 动态可视化1.py
# @Author  : fungis@163.com
# @Time    : 2020/07/16 21:00
# @notice  :
# """
# import pandas as pd
# from keplergl import KeplerGl

# #通过全国七八九月的日均温数据进行渲染
# raw = pd.read_excel('optimizedplans.xlsx')
# map1 = KeplerGl(height=800, data={'layer1': raw})  # 生成Kepler.gl网页
# map1.save_to_html(file_name='output/时间轮播地图示例2019-789.html', data={'layer1': raw})  # 导出网页
